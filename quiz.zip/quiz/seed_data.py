import random
from datetime import datetime, timedelta, timezone
from sqlalchemy.orm import Session
from app.database import engine, SessionLocal
from app.models.base import Base
from app.models.user import User, UserRole
from app.models.question import Question, Choice, DifficultyLevel, QuestionCategory
from app.models.quiz import Quiz, QuizQuestion
from app.models.attempt import QuizAttempt, UserAnswer
from app.models.leaderboard import Leaderboard
from app.core.security import get_password_hash
from app.config import settings

def seed_database():
    print("Initializing Database tables...")
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)

    db: Session = SessionLocal()
    try:
        print("1. Seeding Users (1 Admin, 49 Students)...")
        users = []
        
        # System Admin
        admin = User(
            full_name=settings.ADMIN_NAME,
            username=settings.ADMIN_USERNAME,
            email=settings.ADMIN_EMAIL,
            password_hash=get_password_hash(settings.ADMIN_PASSWORD),
            role=UserRole.ADMIN
        )
        db.add(admin)
        users.append(admin)

        # 49 Students
        first_names = ["Alex", "Jordan", "Taylor", "Morgan", "Sam", "Chris", "Pat", "Riley", "Dakota", "Reese"]
        last_names = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Rodriguez", "Martinez"]

        for i in range(1, 50):
            fn = random.choice(first_names)
            ln = random.choice(last_names)
            username = f"{fn.lower()}{ln.lower()}{i}"
            email = f"{username}@student.quiz.com"
            student = User(
                full_name=f"{fn} {ln}",
                username=username,
                email=email,
                password_hash=get_password_hash("StudentPassword123!"),
                role=UserRole.STUDENT
            )
            db.add(student)
            users.append(student)

        db.commit()
        print(f"   Created {len(users)} users.")

        print("2. Seeding 100 Questions & Choices across 6 categories...")
        categories_data = [
            (QuestionCategory.PROGRAMMING, [
                ("What is the time complexity of searching an element in a balanced Binary Search Tree?", ["O(1)", "O(log n)", "O(n)", "O(n log n)"], 1, "Searching in a balanced BST splits search space in half each step, giving O(log n)."),
                ("Which Python keyword is used to handle exceptions?", ["try/except", "catch", "throw", "handle"], 0, "Python uses try and except blocks to handle runtime exceptions."),
                ("In OOP, what concept describes binding data and functions together into a single unit?", ["Inheritance", "Polymorphism", "Encapsulation", "Abstraction"], 2, "Encapsulation wraps state and methods inside classes to control access."),
                ("What does HTTP status code 404 signify?", ["Unauthorized", "Forbidden", "Not Found", "Internal Server Error"], 2, "HTTP 404 means the requested server resource was not found."),
                ("Which data structure operates on a First-In, First-Out (FIFO) basis?", ["Stack", "Queue", "Tree", "Graph"], 1, "Queues insert at back and remove from front (FIFO)."),
                ("What does GIL stand for in Python?", ["Global Interpreter Lock", "General Interface Logic", "Garbage Internal Loop", "Global Input Layer"], 0, "GIL prevents multiple native threads from executing Python bytecodes simultaneously."),
                ("Which SQL clause is used to filter records after aggregation with GROUP BY?", ["WHERE", "HAVING", "ORDER BY", "FILTER"], 1, "HAVING filters aggregate groups, while WHERE filters rows prior to aggregation."),
                ("What is the primary function of a Docker container?", ["Operating System Virtualization", "Application Level Isolation", "Database Storage", "Network Routing"], 1, "Containers package software dependencies in lightweight isolated environments."),
                ("Which Python data structure is immutable?", ["List", "Dictionary", "Tuple", "Set"], 2, "Tuples cannot be altered once created."),
                ("What algorithm does Git use to hash commits?", ["MD5", "SHA-1 / SHA-256", "RSA", "AES"], 1, "Git computes object IDs using cryptographic SHA hashes.")
            ]),
            (QuestionCategory.MATHEMATICS, [
                ("What is the derivative of f(x) = sin(x)?", ["cos(x)", "-cos(x)", "tan(x)", "-sin(x)"], 0, "d/dx[sin(x)] = cos(x)."),
                ("What is the value of pi rounded to two decimal places?", ["3.12", "3.14", "3.16", "3.18"], 1, "Pi is approximately 3.14159..."),
                ("What is the square root of 625?", ["15", "25", "35", "45"], 1, "25 x 25 = 625."),
                ("If a matrix has a determinant of 0, what is true about its inverse?", ["It is identity", "It does not exist", "It is negative", "It is infinite"], 1, "A matrix with determinant 0 is singular and non-invertible."),
                ("What is 15% of 200?", ["20", "25", "30", "35"], 2, "0.15 x 200 = 30."),
                ("What is the sum of interior angles of a pentagon?", ["360 degrees", "540 degrees", "720 degrees", "900 degrees"], 1, "(n-2)*180 = (5-2)*180 = 540 degrees."),
                ("What is log base 10 of 1000?", ["1", "2", "3", "4"], 2, "10^3 = 1000, so log10(1000) = 3."),
                ("What is the hypotenuse of a right-angled triangle with sides 3 and 4?", ["5", "6", "7", "8"], 0, "Pythagorean theorem: 3^2 + 4^2 = 9 + 16 = 25, sqrt(25) = 5."),
                ("What is the factorial of 5 (5!)?", ["60", "100", "120", "150"], 2, "5! = 5 x 4 x 3 x 2 x 1 = 120."),
                ("Which number is the only even prime number?", ["0", "1", "2", "4"], 2, "2 is divisible only by 1 and itself.")
            ]),
            (QuestionCategory.DATA_SCIENCE, [
                ("Which evaluation metric is best suited for imbalanced binary classification?", ["Accuracy", "ROC-AUC / F1-Score", "Mean Squared Error", "R-Squared"], 1, "F1-Score and ROC-AUC measure precision-recall trade-offs without accuracy bias."),
                ("What technique is used to reduce feature dimensionality while preserving variance?", ["Linear Regression", "Principal Component Analysis (PCA)", "Decision Tree", "K-Means"], 1, "PCA projects high-dimensional data onto orthogonal principal components."),
                ("In machine learning, what occurs during overfitting?", ["Model performs well on training data but poorly on test data", "Model performs poorly on both training and test data", "Model generalizes perfectly", "Model under-allocates features"], 0, "Overfitting captures noise in training data instead of true patterns."),
                ("Which Python library provides high-performance dataframes?", ["NumPy", "Pandas", "Matplotlib", "Scipy"], 1, "Pandas provides DataFrame data structures for manipulation."),
                ("What algorithm partitions data into K distinct non-overlapping clusters?", ["K-Nearest Neighbors", "K-Means", "Support Vector Machine", "Naive Bayes"], 1, "K-Means minimizes within-cluster sum of squares."),
                ("What does MSE stand for in regression tasks?", ["Mean Square Error", "Maximum Sample Estimate", "Median Stat Ensemble", "Model System Evaluation"], 0, "Mean Squared Error averages squared prediction residuals."),
                ("Which activation function outputs values between 0 and 1?", ["ReLU", "Sigmoid", "Tanh", "LeakyReLU"], 1, "Sigmoid S-curve maps any real input to (0, 1)."),
                ("What is the primary assumption of Naive Bayes classifier?", ["Feature independence given class", "Linear separable boundaries", "Normal distribution of labels", "Homoscedasticity"], 0, "Naive Bayes assumes all features are conditionally independent."),
                ("Which cross-validation method splits data into K equal folds?", ["Holdout Method", "K-Fold Cross-Validation", "Leave-One-Out", "Bootstrap"], 1, "K-Fold rotates training and validation across K splits."),
                ("What is the objective function optimized in Logistic Regression?", ["Log Loss / Binary Cross-Entropy", "Sum of Squared Errors", "Hinge Loss", "Gini Impurity"], 0, "Logistic Regression minimizes Log Loss for probability calibration.")
            ]),
            (QuestionCategory.GENERAL_KNOWLEDGE, [
                ("Which planet in our solar system is known as the Red Planet?", ["Venus", "Mars", "Jupiter", "Saturn"], 1, "Mars appears reddish due to iron oxide on its surface."),
                ("Who wrote the play 'Hamlet'?", ["William Shakespeare", "Charles Dickens", "Mark Twain", "Leo Tolstoy"], 0, "William Shakespeare wrote Hamlet around 1600."),
                ("What is the capital city of Japan?", ["Beijing", "Seoul", "Tokyo", "Bangkok"], 2, "Tokyo is the political and commercial capital of Japan."),
                ("Which element has the chemical symbol 'O'?", ["Gold", "Oxygen", "Osmium", "Silver"], 1, "Oxygen is atomic number 8 with symbol O."),
                ("In what year did World War II end?", ["1918", "1939", "1945", "1950"], 2, "WWII concluded in September 1945."),
                ("What is the largest ocean on Earth?", ["Atlantic Ocean", "Indian Ocean", "Arctic Ocean", "Pacific Ocean"], 3, "The Pacific Ocean covers over 30% of Earth's surface."),
                ("Which organ in the human body pumps blood?", ["Brain", "Lungs", "Heart", "Liver"], 2, "The heart circulates blood through blood vessels."),
                ("What currency is used in the United Kingdom?", ["Euro", "Dollar", "Pound Sterling", "Yen"], 2, "The UK uses the British Pound Sterling (GBP)."),
                ("Who painted the Mona Lisa?", ["Vincent van Gogh", "Leonardo da Vinci", "Pablo Picasso", "Michelangelo"], 1, "Leonardo da Vinci painted Mona Lisa in the early 16th century."),
                ("What gas do plants absorb from the atmosphere for photosynthesis?", ["Oxygen", "Carbon Dioxide", "Nitrogen", "Hydrogen"], 1, "Plants absorb CO2 and release Oxygen.")
            ]),
            (QuestionCategory.BUSINESS_STUDIES, [
                ("What does SWOT analysis stand for?", ["Strengths, Weaknesses, Opportunities, Threats", "Sales, Work, Operations, Taxes", "Strategy, Workforce, Objectives, Timeline", "System, Workflow, Output, Targets"], 0, "SWOT evaluates internal and external strategic factors."),
                ("In accounting, what is the fundamental equation?", ["Assets = Liabilities + Owner's Equity", "Revenue = Costs - Taxes", "Profit = Income + Assets", "Equity = Assets * Liabilities"], 0, "Assets equals total liabilities plus shareholder equity."),
                ("What term describes the point where total revenue equals total cost?", ["Profit Margin", "Break-even Point", "Cash Flow Threshold", "ROI"], 1, "Break-even point results in zero net profit or loss."),
                ("What does ROI stand for?", ["Return on Investment", "Rate of Interest", "Risk of Inflation", "Range of Income"], 0, "ROI measures return efficiency relative to investment cost."),
                ("Which marketing P focuses on distribution channels?", ["Product", "Price", "Place", "Promotion"], 2, "Place refers to distribution, logistics, and retail outlets."),
                ("What is liquidity in corporate finance?", ["Ability to convert assets into cash quickly", "Total long-term debt ratio", "Annual stock dividend rate", "Gross profit margin"], 0, "Liquidity reflects how easily assets are converted to liquid cash."),
                ("Who is known as the father of modern management theory?", ["Adam Smith", "Peter Drucker", "Henry Ford", "Steve Jobs"], 1, "Peter Drucker pioneered modern management principles."),
                ("What does B2B stand for?", ["Business to Buyer", "Business to Business", "Brand to Brand", "Bank to Business"], 1, "B2B transactions occur between corporate businesses."),
                ("What financial statement summarizes revenues and expenses over a period?", ["Balance Sheet", "Income Statement / P&L", "Cash Flow Statement", "Audit Report"], 1, "Income Statement details revenues, costs, and net income."),
                ("What term describes a market dominated by a small number of sellers?", ["Monopoly", "Oligopoly", "Perfect Competition", "Monopsony"], 1, "An oligopoly features limited major market suppliers.")
            ]),
            (QuestionCategory.APTITUDE, [
                ("If a car travels at 60 km/h, how far will it travel in 2.5 hours?", ["120 km", "140 km", "150 km", "160 km"], 2, "Distance = Speed x Time = 60 x 2.5 = 150 km."),
                ("Complete the sequence: 2, 4, 8, 16, 32, __?", ["48", "50", "64", "128"], 2, "Each term is doubled (geometric progression with ratio 2)."),
                ("If 5 workers can build a wall in 10 days, how many days will 10 workers take?", ["2 days", "5 days", "10 days", "20 days"], 1, "Work = 5 x 10 = 50 man-days. 50 / 10 workers = 5 days."),
                ("Find the odd one out: Apple, Banana, Carrot, Grape.", ["Apple", "Banana", "Carrot", "Grape"], 2, "Carrot is a root vegetable, whereas the others are fruits."),
                ("If RED is coded as 18-5-4, how is CAB coded?", ["3-1-2", "1-2-3", "3-2-1", "12-1-3"], 0, "Letters correspond to their alphabetical positions (C=3, A=1, B=2)."),
                ("A product costs $80 after a 20% discount. What was the original price?", ["$90", "$100", "$110", "$120"], 1, "0.80 x Original = 80 => Original = $100."),
                ("If all Bloops are Razzies and all Razzies are Lazzies, are all Bloops definitely Lazzies?", ["Yes", "No", "Cannot be determined", "Only on Tuesdays"], 0, "Transitive logical syllogism: Bloops -> Razzies -> Lazzies."),
                ("Average age of 3 friends is 20. If a 4th friend aged 28 joins, what is the new average age?", ["21", "22", "23", "24"], 1, "Sum = 3 x 20 = 60. New Sum = 60 + 28 = 88. New Avg = 88 / 4 = 22."),
                ("A clock shows 3:00. What is the angle between the hour hand and minute hand?", ["45 degrees", "60 degrees", "90 degrees", "180 degrees"], 2, "At 3:00, the minute hand points to 12 and hour hand to 3, forming a 90-degree right angle."),
                ("If A is B's sister, and B is C's mother, how is A related to C?", ["Mother", "Aunt", "Sister", "Grandmother"], 1, "Mother's sister is maternal aunt.")
            ])
        ]

        all_created_questions = []

        # We will create 10 base templates x 10 variations = 100 questions total
        diff_cycle = [DifficultyLevel.EASY, DifficultyLevel.MEDIUM, DifficultyLevel.HARD]
        
        q_counter = 1
        for category, q_list in categories_data:
            for text, choices, correct_idx, expl in q_list:
                diff = diff_cycle[q_counter % 3]
                q_obj = Question(
                    question_text=f"Q{q_counter}: {text}",
                    category=category.value,
                    difficulty=diff,
                    explanation=expl
                )
                db.add(q_obj)
                db.flush()

                for idx, c_text in enumerate(choices):
                    choice_obj = Choice(
                        question_id=q_obj.id,
                        choice_text=c_text,
                        is_correct=(idx == correct_idx)
                    )
                    db.add(choice_obj)

                all_created_questions.append(q_obj)
                q_counter += 1

        # Add remaining to reach exactly 100 questions
        extra_categories = [cat.value for cat in QuestionCategory]
        while len(all_created_questions) < 100:
            cat = extra_categories[len(all_created_questions) % len(extra_categories)]
            diff = diff_cycle[len(all_created_questions) % 3]
            q_obj = Question(
                question_text=f"Q{len(all_created_questions)+1}: Advanced practice concept question for domain {cat} #{len(all_created_questions)+1}",
                category=cat,
                difficulty=diff,
                explanation=f"Explanatory notes for problem #{len(all_created_questions)+1} in {cat}."
            )
            db.add(q_obj)
            db.flush()

            choices = [f"Option A for Q{q_obj.id}", f"Option B for Q{q_obj.id}", f"Option C for Q{q_obj.id}", f"Option D for Q{q_obj.id}"]
            correct_idx = len(all_created_questions) % 4
            for idx, c_text in enumerate(choices):
                choice_obj = Choice(
                    question_id=q_obj.id,
                    choice_text=c_text,
                    is_correct=(idx == correct_idx)
                )
                db.add(choice_obj)

            all_created_questions.append(q_obj)

        db.commit()
        print(f"   Created {len(all_created_questions)} questions with associated choices.")

        print("3. Seeding 20 Quizzes & Assigning Questions...")
        quizzes = []
        quiz_templates = [
            ("Python Core & Data Structures", "Test your knowledge of basic Python types, OOP, and memory execution.", QuestionCategory.PROGRAMMING.value, 15, 100),
            ("Calculus & Algebra Essentials", "Core math concepts covering derivatives, geometry, and equations.", QuestionCategory.MATHEMATICS.value, 20, 100),
            ("Machine Learning & Statistics", "Supervised, unsupervised, evaluation metrics, and ML algorithms.", QuestionCategory.DATA_SCIENCE.value, 25, 100),
            ("World History & Science GK", "General awareness quiz covering geography, science, and history.", QuestionCategory.GENERAL_KNOWLEDGE.value, 10, 100),
            ("Corporate Finance & Strategy", "Business administration, financial accounting, and strategy.", QuestionCategory.BUSINESS_STUDIES.value, 15, 100),
            ("Logical Reasoning & Speed Math", "Aptitude evaluation for problem-solving speed and logic.", QuestionCategory.APTITUDE.value, 15, 100),
            ("Advanced Programming & System Design", "Design patterns, algorithms, system architecture, and containers.", QuestionCategory.PROGRAMMING.value, 30, 100),
            ("Applied Data Science with Pandas", "Data cleaning, feature engineering, PCA, and model evaluation.", QuestionCategory.DATA_SCIENCE.value, 20, 100),
            ("Quantitative Aptitude Drill", "Ratios, percentages, speed, time, and distance drills.", QuestionCategory.APTITUDE.value, 15, 100),
            ("Global Business & Economics", "Monopolies, B2B markets, liquidity, and financial statements.", QuestionCategory.BUSINESS_STUDIES.value, 20, 100),
            ("High School Geometry & Trig", "Angles, triangles, circles, and trigonometric identities.", QuestionCategory.MATHEMATICS.value, 15, 100),
            ("Planet Earth & Astronomy", "Space exploration, planets, oceans, and natural gases.", QuestionCategory.GENERAL_KNOWLEDGE.value, 10, 100),
            ("Full Stack Web Engineering", "HTTP protocols, REST APIs, databases, and microservices.", QuestionCategory.PROGRAMMING.value, 25, 100),
            ("Deep Learning & Neural Networks", "Activation functions, loss functions, backpropagation, and CNNs.", QuestionCategory.DATA_SCIENCE.value, 30, 100),
            ("Project Management & SWOT", "Agile methodologies, strategic planning, and SWOT metrics.", QuestionCategory.BUSINESS_STUDIES.value, 15, 100),
            ("Probability & Statistics Drill", "Combinatorics, normal distribution, log loss, and Bayes.", QuestionCategory.MATHEMATICS.value, 20, 100),
            ("Aptitude Syllogism & Puzzles", "Clock angles, coding-decoding, and family relations.", QuestionCategory.APTITUDE.value, 15, 100),
            ("Arts, Culture & History", "Masterpieces, historical treaties, literature, and capitals.", QuestionCategory.GENERAL_KNOWLEDGE.value, 15, 100),
            ("Comprehensive Grand Challenge", "Mixed multi-domain comprehensive evaluation test.", "Mixed", 45, 100),
            ("Speed Assessment Sprint", "Rapid fire quick-recall multi-category test.", "Mixed", 10, 100),
        ]

        for title, desc, cat, duration, total_marks in quiz_templates:
            quiz = Quiz(
                title=title,
                description=desc,
                category=cat,
                duration=duration,
                total_marks=total_marks
            )
            db.add(quiz)
            db.flush()

            # Assign 5 to 10 matching questions
            if cat == "Mixed":
                matching_qs = random.sample(all_created_questions, 10)
            else:
                cat_qs = [q for q in all_created_questions if q.category == cat]
                matching_qs = random.sample(cat_qs, min(8, len(cat_qs)))

            for q in matching_qs:
                qq = QuizQuestion(quiz_id=quiz.id, question_id=q.id)
                db.add(qq)

            quizzes.append(quiz)

        db.commit()
        print(f"   Created {len(quizzes)} quizzes.")

        print("4. Seeding Quiz Attempts, Answers & Leaderboard entries...")
        student_users = [u for u in users if u.role == UserRole.STUDENT]

        attempt_count = 0
        for student in student_users:
            # Each student attempts 2-4 random quizzes
            chosen_quizzes = random.sample(quizzes, random.randint(2, 4))
            for qz in chosen_quizzes:
                q_questions = [qq.question for qq in qz.quiz_questions]
                if not q_questions:
                    continue

                marks_per_q = qz.total_marks / float(len(q_questions))
                total_score = 0.0

                start_time = datetime.now(timezone.utc) - timedelta(days=random.randint(1, 20), minutes=random.randint(10, 500))
                end_time = start_time + timedelta(minutes=random.randint(5, qz.duration))

                attempt = QuizAttempt(
                    user_id=student.id,
                    quiz_id=qz.id,
                    start_time=start_time,
                    end_time=end_time,
                    score=0.0,
                    percentage=0.0,
                    submitted=True
                )
                db.add(attempt)
                db.flush()

                for q in q_questions:
                    choices = q.choices
                    correct_choice = next((c for c in choices if c.is_correct), None)
                    
                    # 70% probability student picks correct answer
                    is_correct_pick = random.random() < 0.70
                    if is_correct_pick and correct_choice:
                        selected_choice = correct_choice
                        total_score += marks_per_q
                    else:
                        wrong_choices = [c for c in choices if not c.is_correct]
                        selected_choice = random.choice(wrong_choices) if wrong_choices else None

                    ua = UserAnswer(
                        attempt_id=attempt.id,
                        question_id=q.id,
                        selected_choice_id=selected_choice.id if selected_choice else None,
                        is_correct=(is_correct_pick and bool(correct_choice))
                    )
                    db.add(ua)

                pct = round((total_score / float(qz.total_marks)) * 100.0, 2)
                attempt.score = round(total_score, 2)
                attempt.percentage = pct

                # Leaderboard update
                lb_entry = db.query(Leaderboard).filter(Leaderboard.quiz_id == qz.id, Leaderboard.user_id == student.id).first()
                if not lb_entry:
                    lb_entry = Leaderboard(
                        quiz_id=qz.id,
                        user_id=student.id,
                        score=attempt.score,
                        rank=1,
                        updated_at=end_time
                    )
                    db.add(lb_entry)
                elif attempt.score > lb_entry.score:
                    lb_entry.score = attempt.score
                    lb_entry.updated_at = end_time

                attempt_count += 1

        db.commit()

        # Recalculate ranks across all leaderboards
        for qz in quizzes:
            entries = db.query(Leaderboard).filter(Leaderboard.quiz_id == qz.id).order_by(Leaderboard.score.desc()).all()
            for rank_idx, entry in enumerate(entries, start=1):
                entry.rank = rank_idx
        db.commit()

        print(f"   Created {attempt_count} submitted quiz attempts and updated leaderboards.")
        print("\nDATABASE SEEDING COMPLETE SUCCESSFULLY!")

    except Exception as e:
        db.rollback()
        print(f"Error seeding database: {e}")
        raise e
    finally:
        db.close()

if __name__ == "__main__":
    seed_database()
