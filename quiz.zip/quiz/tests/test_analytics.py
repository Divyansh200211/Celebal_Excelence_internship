from fastapi.testclient import TestClient


def test_admin_dashboard_analytics(client: TestClient, admin_headers: dict):
    response = client.get("/api/v1/analytics/admin-dashboard", headers=admin_headers)
    assert response.status_code == 200
    data = response.json()
    assert "total_users" in data
    assert "total_questions" in data
    assert "total_quizzes" in data
    assert "category_wise_performance" in data


def test_student_dashboard_analytics(client: TestClient, student_headers: dict):
    response = client.get("/api/v1/analytics/user-dashboard", headers=student_headers)
    assert response.status_code == 200
    data = response.json()
    assert "total_attempts" in data
    assert "highest_score" in data
