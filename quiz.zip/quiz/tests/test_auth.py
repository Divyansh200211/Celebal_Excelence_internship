from fastapi.testclient import TestClient
from app.models.user import User


def test_register_user_success(client: TestClient):
    payload = {
        "full_name": "Alice Smith",
        "username": "alicesmith",
        "email": "alice@example.com",
        "password": "Password123!",
        "role": "student"
    }
    response = client.post("/api/v1/auth/register", json=payload)
    assert response.status_code == 201
    data = response.json()
    assert data["username"] == "alicesmith"
    assert data["email"] == "alice@example.com"
    assert data["role"] == "student"
    assert "id" in data


def test_register_duplicate_email(client: TestClient, student_user: User):
    payload = {
        "full_name": "Duplicate Alice",
        "username": "unique_username",
        "email": student_user.email,  # duplicate
        "password": "Password123!",
        "role": "student"
    }
    response = client.post("/api/v1/auth/register", json=payload)
    assert response.status_code == 409
    assert "already registered" in response.json()["detail"]


def test_login_success(client: TestClient, student_user: User):
    response = client.post(
        "/api/v1/auth/login",
        data={"username": student_user.username, "password": "StudentPass123!"}
    )
    assert response.status_code == 200
    data = response.json()
    assert "access_token" in data
    assert "refresh_token" in data
    assert data["user"]["username"] == student_user.username


def test_login_invalid_password(client: TestClient, student_user: User):
    response = client.post(
        "/api/v1/auth/login",
        data={"username": student_user.username, "password": "WrongPassword"}
    )
    assert response.status_code == 401


def test_get_me(client: TestClient, student_headers: dict, student_user: User):
    response = client.get("/api/v1/auth/me", headers=student_headers)
    assert response.status_code == 200
    data = response.json()
    assert data["username"] == student_user.username
    assert data["email"] == student_user.email
