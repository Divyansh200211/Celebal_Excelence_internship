from fastapi.testclient import TestClient


def test_leaderboard_endpoints(client: TestClient, student_headers: dict):
    # Test global leaderboard
    g_resp = client.get("/api/v1/leaderboard/global", headers=student_headers)
    assert g_resp.status_code == 200
    assert "Global Leaderboard" in g_resp.json()["title"]

    # Test weekly leaderboard
    w_resp = client.get("/api/v1/leaderboard/weekly", headers=student_headers)
    assert w_resp.status_code == 200

    # Test monthly leaderboard
    m_resp = client.get("/api/v1/leaderboard/monthly", headers=student_headers)
    assert m_resp.status_code == 200
