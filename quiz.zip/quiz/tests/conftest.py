import pytest
from typing import Generator
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.pool import StaticPool

from app.main import app
from app.database import get_db
from app.models.base import Base
from app.models.user import User, UserRole
from app.core.security import get_password_hash, create_access_token

# In-memory SQLite for isolated fast test runs
SQLALCHEMY_DATABASE_URL = "sqlite:///:memory:"

engine = create_engine(
    SQLALCHEMY_DATABASE_URL,
    connect_args={"check_same_thread": False},
    poolclass=StaticPool
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


@pytest.fixture(scope="function")
def db_session() -> Generator[Session, None, None]:
    """Creates a clean database schema per test function."""
    Base.metadata.create_all(bind=engine)
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()
        Base.metadata.drop_all(bind=engine)


@pytest.fixture(scope="function")
def client(db_session: Session) -> Generator[TestClient, None, None]:
    """FastAPI TestClient with overridden get_db dependency."""
    def override_get_db():
        try:
            yield db_session
        finally:
            pass

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as c:
        yield c
    app.dependency_overrides.clear()


@pytest.fixture
def admin_user(db_session: Session) -> User:
    """Creates a sample Admin user."""
    admin = User(
        full_name="Test Admin",
        username="admin_test",
        email="admin_test@quiz.com",
        password_hash=get_password_hash("AdminPass123!"),
        role=UserRole.ADMIN
    )
    db_session.add(admin)
    db_session.commit()
    db_session.refresh(admin)
    return admin


@pytest.fixture
def student_user(db_session: Session) -> User:
    """Creates a sample Student user."""
    student = User(
        full_name="Test Student",
        username="student_test",
        email="student_test@quiz.com",
        password_hash=get_password_hash("StudentPass123!"),
        role=UserRole.STUDENT
    )
    db_session.add(student)
    db_session.commit()
    db_session.refresh(student)
    return student


@pytest.fixture
def admin_headers(admin_user: User) -> dict:
    """JWT Authorization header for Admin."""
    token = create_access_token(subject=admin_user.id, role=admin_user.role.value)
    return {"Authorization": f"Bearer {token}"}


@pytest.fixture
def student_headers(student_user: User) -> dict:
    """JWT Authorization header for Student."""
    token = create_access_token(subject=student_user.id, role=student_user.role.value)
    return {"Authorization": f"Bearer {token}"}
