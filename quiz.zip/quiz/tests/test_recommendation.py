from fastapi.testclient import TestClient


def test_get_recommendations(client: TestClient, admin_headers: dict, student_headers: dict):
    # 1. Create a quiz first
    client.post("/api/v1/quizzes", json={
        "title": "Data Science Recommendation Test Quiz",
        "description": "Scikit learn recommendation testing quiz",
        "category": "Data Science",
        "duration": 15,
        "total_marks": 100
    }, headers=admin_headers)

    # 2. Get recommendations for student
    response = client.get("/api/v1/recommendations", headers=student_headers)
    assert response.status_code == 200
    data = response.json()
    assert "recommendations" in data
    assert len(data["recommendations"]) > 0
    assert "match_score" in data["recommendations"][0]
