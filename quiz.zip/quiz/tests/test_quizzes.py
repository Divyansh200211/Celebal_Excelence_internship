from fastapi.testclient import TestClient


def test_create_quiz_and_assign_questions(client: TestClient, admin_headers: dict):
    # 1. Create 2 questions
    q1 = client.post("/api/v1/questions", json={
        "question_text": "Q1 text",
        "category": "Math",
        "difficulty": "easy",
        "choices": [{"choice_text": "A", "is_correct": True}, {"choice_text": "B", "is_correct": False}]
    }, headers=admin_headers).json()

    q2 = client.post("/api/v1/questions", json={
        "question_text": "Q2 text",
        "category": "Math",
        "difficulty": "medium",
        "choices": [{"choice_text": "C", "is_correct": True}, {"choice_text": "D", "is_correct": False}]
    }, headers=admin_headers).json()

    # 2. Create Quiz with questions
    quiz_payload = {
        "title": "Math Fundamentals",
        "description": "Basic math evaluation test",
        "category": "Math",
        "duration": 15,
        "total_marks": 100,
        "question_ids": [q1["id"], q2["id"]]
    }
    response = client.post("/api/v1/quizzes", json=quiz_payload, headers=admin_headers)
    assert response.status_code == 201
    data = response.json()
    assert data["title"] == "Math Fundamentals"
    assert data["question_count"] == 2


def test_generate_random_quiz(client: TestClient, admin_headers: dict):
    # Create questions first
    for i in range(5):
        client.post("/api/v1/questions", json={
            "question_text": f"Random Q{i}",
            "category": "Aptitude",
            "difficulty": "easy",
            "choices": [{"choice_text": "X", "is_correct": True}, {"choice_text": "Y", "is_correct": False}]
        }, headers=admin_headers)

    gen_payload = {
        "title": "Auto Generated Aptitude Test",
        "description": "Random quiz generator test",
        "category": "Aptitude",
        "num_questions": 3,
        "duration": 10
    }
    response = client.post("/api/v1/quizzes/generate/random", json=gen_payload, headers=admin_headers)
    assert response.status_code == 201
    assert response.json()["question_count"] == 3
