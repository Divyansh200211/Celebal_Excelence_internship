from fastapi.testclient import TestClient


def test_quiz_attempt_flow(client: TestClient, admin_headers: dict, student_headers: dict):
    # 1. Admin creates question and quiz
    q_resp = client.post("/api/v1/questions", json={
        "question_text": "What is 2 + 2?",
        "category": "Mathematics",
        "difficulty": "easy",
        "choices": [
            {"choice_text": "3", "is_correct": False},
            {"choice_text": "4", "is_correct": True}
        ]
    }, headers=admin_headers).json()

    q_id = q_resp["id"]
    correct_choice_id = [c["id"] for c in q_resp["choices"] if c["is_correct"]][0]

    quiz_resp = client.post("/api/v1/quizzes", json={
        "title": "Addition Speed Test",
        "description": "Simple addition quiz",
        "category": "Mathematics",
        "duration": 5,
        "total_marks": 10,
        "question_ids": [q_id]
    }, headers=admin_headers).json()

    quiz_id = quiz_resp["id"]

    # 2. Student starts quiz attempt
    start_resp = client.post(f"/api/v1/attempts/start/{quiz_id}", headers=student_headers)
    assert start_resp.status_code == 201
    attempt_data = start_resp.json()
    attempt_id = attempt_data["attempt_id"]

    # 3. Check timer API
    timer_resp = client.get(f"/api/v1/attempts/{attempt_id}/timer", headers=student_headers)
    assert timer_resp.status_code == 200
    assert timer_resp.json()["remaining_seconds"] > 0

    # 4. Submit correct choice
    submit_payload = {
        "answers": [
            {"question_id": q_id, "selected_choice_id": correct_choice_id}
        ]
    }
    submit_resp = client.post(f"/api/v1/attempts/{attempt_id}/submit", json=submit_payload, headers=student_headers)
    assert submit_resp.status_code == 200
    report = submit_resp.json()
    assert report["score"] == 10.0
    assert report["percentage"] == 100.0
    assert report["correct_count"] == 1
