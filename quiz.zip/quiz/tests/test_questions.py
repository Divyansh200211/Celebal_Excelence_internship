from fastapi.testclient import TestClient


def test_create_question_admin(client: TestClient, admin_headers: dict):
    payload = {
        "question_text": "What is Python?",
        "category": "Programming",
        "difficulty": "easy",
        "explanation": "High-level programming language.",
        "choices": [
            {"choice_text": "A programming language", "is_correct": True},
            {"choice_text": "A type of snake", "is_correct": False}
        ]
    }
    response = client.post("/api/v1/questions", json=payload, headers=admin_headers)
    assert response.status_code == 201
    data = response.json()
    assert data["question_text"] == "What is Python?"
    assert len(data["choices"]) == 2


def test_create_question_student_forbidden(client: TestClient, student_headers: dict):
    payload = {
        "question_text": "Can student create question?",
        "category": "Programming",
        "choices": [
            {"choice_text": "Yes", "is_correct": True},
            {"choice_text": "No", "is_correct": False}
        ]
    }
    response = client.post("/api/v1/questions", json=payload, headers=student_headers)
    assert response.status_code == 403


def test_delete_question_cascading(client: TestClient, admin_headers: dict):
    # Create question first
    payload = {
        "question_text": "To be deleted question?",
        "category": "General Knowledge",
        "difficulty": "medium",
        "choices": [
            {"choice_text": "Opt A", "is_correct": True},
            {"choice_text": "Opt B", "is_correct": False}
        ]
    }
    create_resp = client.post("/api/v1/questions", json=payload, headers=admin_headers)
    q_id = create_resp.json()["id"]

    # Delete question
    del_resp = client.delete(f"/api/v1/questions/{q_id}", headers=admin_headers)
    assert del_resp.status_code == 200

    # Verify 404
    get_resp = client.get(f"/api/v1/questions/{q_id}", headers=admin_headers)
    assert get_resp.status_code == 404
