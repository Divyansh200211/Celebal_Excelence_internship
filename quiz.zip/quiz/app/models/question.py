import enum
from datetime import datetime, timezone
from typing import List, TYPE_CHECKING, Optional
from sqlalchemy import String, Text, Enum, DateTime, ForeignKey, Boolean, Integer
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.models.base import Base

if TYPE_CHECKING:
    from app.models.quiz import QuizQuestion
    from app.models.attempt import UserAnswer


class DifficultyLevel(str, enum.Enum):
    EASY = "easy"
    MEDIUM = "medium"
    HARD = "hard"


class QuestionCategory(str, enum.Enum):
    PROGRAMMING = "Programming"
    MATHEMATICS = "Mathematics"
    GENERAL_KNOWLEDGE = "General Knowledge"
    DATA_SCIENCE = "Data Science"
    BUSINESS_STUDIES = "Business Studies"
    APTITUDE = "Aptitude"
    OTHER = "Other"


class Question(Base):
    __tablename__ = "questions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    question_text: Mapped[str] = mapped_column(Text, nullable=False)
    category: Mapped[str] = mapped_column(String(100), index=True, nullable=False)
    difficulty: Mapped[DifficultyLevel] = mapped_column(Enum(DifficultyLevel), default=DifficultyLevel.MEDIUM, nullable=False)
    explanation: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        nullable=False
    )

    # Relationships
    choices: Mapped[List["Choice"]] = relationship("Choice", back_populates="question", cascade="all, delete-orphan", lazy="selectin")
    quiz_associations: Mapped[List["QuizQuestion"]] = relationship("QuizQuestion", back_populates="question", cascade="all, delete-orphan")
    user_answers: Mapped[List["UserAnswer"]] = relationship("UserAnswer", back_populates="question", cascade="all, delete-orphan")


class Choice(Base):
    __tablename__ = "choices"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    question_id: Mapped[int] = mapped_column(Integer, ForeignKey("questions.id", ondelete="CASCADE"), nullable=False, index=True)
    choice_text: Mapped[str] = mapped_column(String(500), nullable=False)
    is_correct: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)

    # Relationship
    question: Mapped["Question"] = relationship("Question", back_populates="choices")
