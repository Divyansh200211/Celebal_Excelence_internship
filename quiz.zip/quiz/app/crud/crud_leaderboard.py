from datetime import datetime, timedelta, timezone
from typing import List
from sqlalchemy import func, desc
from sqlalchemy.orm import Session
from app.models.leaderboard import Leaderboard
from app.models.attempt import QuizAttempt
from app.models.user import User
from app.models.quiz import Quiz


class CRUDLeaderboard:
    def update_or_create_entry(
        self,
        db: Session,
        quiz_id: int,
        user_id: int,
        score: float
    ) -> Leaderboard:
        entry = db.query(Leaderboard).filter(
            Leaderboard.quiz_id == quiz_id,
            Leaderboard.user_id == user_id
        ).first()

        if entry:
            if score > entry.score:
                entry.score = score
                entry.updated_at = datetime.now(timezone.utc)
        else:
            entry = Leaderboard(
                quiz_id=quiz_id,
                user_id=user_id,
                score=score,
                rank=0,
                updated_at=datetime.now(timezone.utc)
            )
            db.add(entry)

        db.commit()
        db.refresh(entry)

        # Recalculate ranks for this quiz
        self._recalculate_quiz_ranks(db, quiz_id)
        return entry

    def _recalculate_quiz_ranks(self, db: Session, quiz_id: int):
        entries = db.query(Leaderboard).filter(Leaderboard.quiz_id == quiz_id).order_by(Leaderboard.score.desc()).all()
        for idx, entry in enumerate(entries, start=1):
            entry.rank = idx
        db.commit()

    def get_global_leaderboard(self, db: Session, limit: int = 10) -> List[dict]:
        """Calculates global total highest score per user across all quizzes."""
        subquery = (
            db.query(
                Leaderboard.user_id,
                func.sum(Leaderboard.score).label("total_score"),
                func.max(Leaderboard.updated_at).label("latest_update")
            )
            .group_by(Leaderboard.user_id)
            .subquery()
        )

        results = (
            db.query(User, subquery.c.total_score, subquery.c.latest_update)
            .join(subquery, User.id == subquery.c.user_id)
            .order_by(subquery.c.total_score.desc())
            .limit(limit)
            .all()
        )

        output = []
        for idx, (user, total_score, latest_update) in enumerate(results, start=1):
            output.append({
                "rank": idx,
                "user_id": user.id,
                "username": user.username,
                "full_name": user.full_name,
                "score": float(total_score),
                "updated_at": latest_update
            })
        return output

    def get_quiz_leaderboard(self, db: Session, quiz_id: int, limit: int = 10) -> List[dict]:
        entries = (
            db.query(Leaderboard, User, Quiz)
            .join(User, Leaderboard.user_id == User.id)
            .join(Quiz, Leaderboard.quiz_id == Quiz.id)
            .filter(Leaderboard.quiz_id == quiz_id)
            .order_by(Leaderboard.score.desc())
            .limit(limit)
            .all()
        )

        output = []
        for idx, (lb, user, quiz) in enumerate(entries, start=1):
            output.append({
                "rank": idx,
                "user_id": user.id,
                "username": user.username,
                "full_name": user.full_name,
                "score": lb.score,
                "quiz_id": quiz.id,
                "quiz_title": quiz.title,
                "updated_at": lb.updated_at
            })
        return output

    def get_timeframe_leaderboard(self, db: Session, days: int = 7, limit: int = 10) -> List[dict]:
        start_date = datetime.now(timezone.utc) - timedelta(days=days)
        subquery = (
            db.query(
                QuizAttempt.user_id,
                func.sum(QuizAttempt.score).label("total_score"),
                func.max(QuizAttempt.start_time).label("latest_update")
            )
            .filter(QuizAttempt.submitted == True, QuizAttempt.start_time >= start_date)
            .group_by(QuizAttempt.user_id)
            .subquery()
        )

        results = (
            db.query(User, subquery.c.total_score, subquery.c.latest_update)
            .join(subquery, User.id == subquery.c.user_id)
            .order_by(subquery.c.total_score.desc())
            .limit(limit)
            .all()
        )

        output = []
        for idx, (user, total_score, latest_update) in enumerate(results, start=1):
            output.append({
                "rank": idx,
                "user_id": user.id,
                "username": user.username,
                "full_name": user.full_name,
                "score": float(total_score if total_score else 0.0),
                "updated_at": latest_update or datetime.now(timezone.utc)
            })
        return output


crud_leaderboard = CRUDLeaderboard()
