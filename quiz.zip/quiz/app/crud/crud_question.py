from typing import Optional, List, Tuple
from sqlalchemy import or_
from sqlalchemy.orm import Session
from app.models.question import Question, Choice, DifficultyLevel
from app.schemas.question import QuestionCreate, QuestionUpdate, ChoiceCreate, ChoiceUpdate


class CRUDQuestion:
    def get_by_id(self, db: Session, question_id: int) -> Optional[Question]:
        return db.query(Question).filter(Question.id == question_id).first()

    def create(self, db: Session, obj_in: QuestionCreate) -> Question:
        db_question = Question(
            question_text=obj_in.question_text,
            category=obj_in.category,
            difficulty=obj_in.difficulty,
            explanation=obj_in.explanation
        )
        db.add(db_question)
        db.flush()  # to get db_question.id

        for choice_in in obj_in.choices:
            db_choice = Choice(
                question_id=db_question.id,
                choice_text=choice_in.choice_text,
                is_correct=choice_in.is_correct
            )
            db.add(db_choice)

        db.commit()
        db.refresh(db_question)
        return db_question

    def update(self, db: Session, db_obj: Question, obj_in: QuestionUpdate) -> Question:
        update_data = obj_in.model_dump(exclude_unset=True)
        for field, value in update_data.items():
            setattr(db_obj, field, value)
        db.commit()
        db.refresh(db_obj)
        return db_obj

    def delete(self, db: Session, question_id: int) -> bool:
        db_obj = db.query(Question).filter(Question.id == question_id).first()
        if not db_obj:
            return False
        db.delete(db_obj)
        db.commit()
        return True

    def get_multi(
        self,
        db: Session,
        page: int = 1,
        page_size: int = 10,
        category: Optional[str] = None,
        difficulty: Optional[DifficultyLevel] = None,
        search: Optional[str] = None
    ) -> Tuple[List[Question], int]:
        query = db.query(Question)

        if category:
            query = query.filter(Question.category.ilike(f"%{category}%"))
        if difficulty:
            query = query.filter(Question.difficulty == difficulty)
        if search:
            query = query.filter(
                or_(
                    Question.question_text.ilike(f"%{search}%"),
                    Question.explanation.ilike(f"%{search}%")
                )
            )

        total = query.count()
        questions = query.order_by(Question.id.desc()).offset((page - 1) * page_size).limit(page_size).all()
        return questions, total

    # Choice operations
    def get_choice_by_id(self, db: Session, choice_id: int) -> Optional[Choice]:
        return db.query(Choice).filter(Choice.id == choice_id).first()

    def get_choices_for_question(self, db: Session, question_id: int) -> List[Choice]:
        return db.query(Choice).filter(Choice.question_id == question_id).all()

    def add_choice(self, db: Session, question_id: int, obj_in: ChoiceCreate) -> Choice:
        db_choice = Choice(
            question_id=question_id,
            choice_text=obj_in.choice_text,
            is_correct=obj_in.is_correct
        )
        db.add(db_choice)
        db.commit()
        db.refresh(db_choice)
        return db_choice

    def update_choice(self, db: Session, db_choice: Choice, obj_in: ChoiceUpdate) -> Choice:
        update_data = obj_in.model_dump(exclude_unset=True)
        for field, value in update_data.items():
            setattr(db_choice, field, value)
        db.commit()
        db.refresh(db_choice)
        return db_choice

    def delete_choice(self, db: Session, choice_id: int) -> bool:
        db_obj = db.query(Choice).filter(Choice.id == choice_id).first()
        if not db_obj:
            return False
        db.delete(db_obj)
        db.commit()
        return True


crud_question = CRUDQuestion()
