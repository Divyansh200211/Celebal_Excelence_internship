from typing import Optional, List, Tuple
from sqlalchemy import or_
from sqlalchemy.orm import Session
from app.models.quiz import Quiz, QuizQuestion
from app.models.question import Question
from app.schemas.quiz import QuizCreate, QuizUpdate


class CRUDQuiz:
    def get_by_id(self, db: Session, quiz_id: int) -> Optional[Quiz]:
        return db.query(Quiz).filter(Quiz.id == quiz_id).first()

    def create(self, db: Session, obj_in: QuizCreate) -> Quiz:
        db_quiz = Quiz(
            title=obj_in.title,
            description=obj_in.description,
            category=obj_in.category,
            duration=obj_in.duration,
            total_marks=obj_in.total_marks
        )
        db.add(db_quiz)
        db.flush()

        if obj_in.question_ids:
            for q_id in obj_in.question_ids:
                # verify question exists
                q = db.query(Question).filter(Question.id == q_id).first()
                if q:
                    qq = QuizQuestion(quiz_id=db_quiz.id, question_id=q_id)
                    db.add(qq)

        db.commit()
        db.refresh(db_quiz)
        return db_quiz

    def update(self, db: Session, db_obj: Quiz, obj_in: QuizUpdate) -> Quiz:
        update_data = obj_in.model_dump(exclude_unset=True)
        for field, value in update_data.items():
            setattr(db_obj, field, value)
        db.commit()
        db.refresh(db_obj)
        return db_obj

    def delete(self, db: Session, quiz_id: int) -> bool:
        db_obj = db.query(Quiz).filter(Quiz.id == quiz_id).first()
        if not db_obj:
            return False
        db.delete(db_obj)
        db.commit()
        return True

    def get_multi(
        self,
        db: Session,
        page: int = 1,
        page_size: int = 10,
        category: Optional[str] = None,
        search: Optional[str] = None
    ) -> Tuple[List[Quiz], int]:
        query = db.query(Quiz)

        if category:
            query = query.filter(Quiz.category.ilike(f"%{category}%"))
        if search:
            query = query.filter(
                or_(
                    Quiz.title.ilike(f"%{search}%"),
                    Quiz.description.ilike(f"%{search}%")
                )
            )

        total = query.count()
        quizzes = query.order_by(Quiz.id.desc()).offset((page - 1) * page_size).limit(page_size).all()
        return quizzes, total

    def assign_questions(self, db: Session, quiz_id: int, question_ids: List[int]) -> Quiz:
        quiz = self.get_by_id(db, quiz_id)
        if not quiz:
            return None

        # Existing attached question IDs
        existing_ids = {qq.question_id for qq in quiz.quiz_questions}

        for q_id in question_ids:
            if q_id not in existing_ids:
                q = db.query(Question).filter(Question.id == q_id).first()
                if q:
                    qq = QuizQuestion(quiz_id=quiz_id, question_id=q_id)
                    db.add(qq)

        db.commit()
        db.refresh(quiz)
        return quiz

    def remove_question(self, db: Session, quiz_id: int, question_id: int) -> bool:
        qq = db.query(QuizQuestion).filter(
            QuizQuestion.quiz_id == quiz_id,
            QuizQuestion.question_id == question_id
        ).first()
        if not qq:
            return False
        db.delete(qq)
        db.commit()
        return True

    def get_quiz_questions(self, db: Session, quiz_id: int) -> List[Question]:
        quiz_questions = db.query(QuizQuestion).filter(QuizQuestion.quiz_id == quiz_id).all()
        q_ids = [qq.question_id for qq in quiz_questions]
        return db.query(Question).filter(Question.id.in_(q_ids)).all()


crud_quiz = CRUDQuiz()
