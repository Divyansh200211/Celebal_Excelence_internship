from datetime import datetime, timezone
from typing import Optional, List, Tuple
from sqlalchemy.orm import Session
from app.models.attempt import QuizAttempt, UserAnswer
from app.models.quiz import Quiz
from app.models.user import User


class CRUDAttempt:
    def get_by_id(self, db: Session, attempt_id: int) -> Optional[QuizAttempt]:
        return db.query(QuizAttempt).filter(QuizAttempt.id == attempt_id).first()

    def get_active_attempt(self, db: Session, user_id: int, quiz_id: int) -> Optional[QuizAttempt]:
        return db.query(QuizAttempt).filter(
            QuizAttempt.user_id == user_id,
            QuizAttempt.quiz_id == quiz_id,
            QuizAttempt.submitted == False
        ).order_by(QuizAttempt.start_time.desc()).first()

    def create_attempt(self, db: Session, user_id: int, quiz_id: int) -> QuizAttempt:
        attempt = QuizAttempt(
            user_id=user_id,
            quiz_id=quiz_id,
            start_time=datetime.now(timezone.utc),
            submitted=False,
            score=0.0,
            percentage=0.0
        )
        db.add(attempt)
        db.commit()
        db.refresh(attempt)
        return attempt

    def save_user_answer(
        self,
        db: Session,
        attempt_id: int,
        question_id: int,
        selected_choice_id: Optional[int],
        is_correct: bool
    ) -> UserAnswer:
        existing = db.query(UserAnswer).filter(
            UserAnswer.attempt_id == attempt_id,
            UserAnswer.question_id == question_id
        ).first()

        if existing:
            existing.selected_choice_id = selected_choice_id
            existing.is_correct = is_correct
            db.commit()
            db.refresh(existing)
            return existing
        else:
            ua = UserAnswer(
                attempt_id=attempt_id,
                question_id=question_id,
                selected_choice_id=selected_choice_id,
                is_correct=is_correct
            )
            db.add(ua)
            db.commit()
            db.refresh(ua)
            return ua

    def finalize_attempt(
        self,
        db: Session,
        attempt: QuizAttempt,
        score: float,
        percentage: float
    ) -> QuizAttempt:
        attempt.score = score
        attempt.percentage = percentage
        attempt.submitted = True
        attempt.end_time = datetime.now(timezone.utc)
        db.commit()
        db.refresh(attempt)
        return attempt

    def get_user_attempts(
        self,
        db: Session,
        user_id: int,
        page: int = 1,
        page_size: int = 10
    ) -> Tuple[List[QuizAttempt], int]:
        query = db.query(QuizAttempt).filter(QuizAttempt.user_id == user_id)
        total = query.count()
        attempts = query.order_by(QuizAttempt.start_time.desc()).offset((page - 1) * page_size).limit(page_size).all()
        return attempts, total


crud_attempt = CRUDAttempt()
