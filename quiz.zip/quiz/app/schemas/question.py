from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel, ConfigDict, Field
from app.models.question import DifficultyLevel


class ChoiceBase(BaseModel):
    choice_text: str = Field(..., min_length=1, max_length=500, example="Python")
    is_correct: bool = Field(default=False, example=True)


class ChoiceCreate(ChoiceBase):
    pass


class ChoiceUpdate(BaseModel):
    choice_text: Optional[str] = Field(None, min_length=1, max_length=500)
    is_correct: Optional[bool] = None


class ChoiceResponse(ChoiceBase):
    id: int
    question_id: int

    model_config = ConfigDict(from_attributes=True)


class QuestionBase(BaseModel):
    question_text: str = Field(..., min_length=3, example="Which programming language is known as Python's creator?")
    category: str = Field(..., min_length=2, max_length=100, example="Programming")
    difficulty: DifficultyLevel = Field(default=DifficultyLevel.MEDIUM, example="medium")
    explanation: Optional[str] = Field(None, example="Guido van Rossum released Python in 1991.")


class QuestionCreate(QuestionBase):
    choices: List[ChoiceCreate] = Field(..., min_items=2, description="At least two choices must be provided.")


class QuestionUpdate(BaseModel):
    question_text: Optional[str] = Field(None, min_length=3)
    category: Optional[str] = Field(None, min_length=2, max_length=100)
    difficulty: Optional[DifficultyLevel] = None
    explanation: Optional[str] = None


class QuestionResponse(QuestionBase):
    id: int
    created_at: datetime
    choices: List[ChoiceResponse] = []

    model_config = ConfigDict(from_attributes=True)
