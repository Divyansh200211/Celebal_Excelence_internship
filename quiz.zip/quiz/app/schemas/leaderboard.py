from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel, ConfigDict


class LeaderboardEntryResponse(BaseModel):
    rank: int
    user_id: int
    username: str
    full_name: str
    score: float
    quiz_id: Optional[int] = None
    quiz_title: Optional[str] = None
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True)


class LeaderboardListResponse(BaseModel):
    title: str
    total_entries: int
    entries: List[LeaderboardEntryResponse]
