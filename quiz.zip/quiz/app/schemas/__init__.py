from app.schemas.common import PaginationParams, PaginatedResponse, GenericMessageResponse
from app.schemas.user import UserCreate, UserUpdate, UserResponse, UserLogin, TokenResponse, TokenRefreshRequest
from app.schemas.question import ChoiceCreate, ChoiceUpdate, ChoiceResponse, QuestionCreate, QuestionUpdate, QuestionResponse
from app.schemas.quiz import QuizCreate, QuizUpdate, QuizResponse, AssignQuestionsRequest, RandomQuizGenerateRequest, CategoryQuizGenerateRequest, DifficultyQuizGenerateRequest, MixedQuizGenerateRequest
from app.schemas.attempt import SingleAnswerSubmit, QuizAttemptStartResponse, QuizAttemptTimerResponse, QuizAttemptSubmitRequest, QuizAttemptReportResponse, UserScoreSummary
from app.schemas.leaderboard import LeaderboardEntryResponse, LeaderboardListResponse
from app.schemas.analytics import AdminDashboardAnalytics
from app.schemas.recommendation import SingleRecommendationItem, RecommendationListResponse

__all__ = [
    "PaginationParams",
    "PaginatedResponse",
    "GenericMessageResponse",
    "UserCreate",
    "UserUpdate",
    "UserResponse",
    "UserLogin",
    "TokenResponse",
    "TokenRefreshRequest",
    "ChoiceCreate",
    "ChoiceUpdate",
    "ChoiceResponse",
    "QuestionCreate",
    "QuestionUpdate",
    "QuestionResponse",
    "QuizCreate",
    "QuizUpdate",
    "QuizResponse",
    "AssignQuestionsRequest",
    "RandomQuizGenerateRequest",
    "CategoryQuizGenerateRequest",
    "DifficultyQuizGenerateRequest",
    "MixedQuizGenerateRequest",
    "SingleAnswerSubmit",
    "QuizAttemptStartResponse",
    "QuizAttemptTimerResponse",
    "QuizAttemptSubmitRequest",
    "QuizAttemptReportResponse",
    "UserScoreSummary",
    "LeaderboardEntryResponse",
    "LeaderboardListResponse",
    "AdminDashboardAnalytics",
    "SingleRecommendationItem",
    "RecommendationListResponse",
]
