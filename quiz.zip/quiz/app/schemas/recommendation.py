from datetime import datetime
from typing import List
from pydantic import BaseModel, ConfigDict
from app.schemas.quiz import QuizResponse


class SingleRecommendationItem(BaseModel):
    quiz: QuizResponse
    match_score: float
    reason: str
    predicted_score: float

    model_config = ConfigDict(from_attributes=True)


class RecommendationListResponse(BaseModel):
    user_id: int
    generated_at: datetime
    recommendations: List[SingleRecommendationItem]
