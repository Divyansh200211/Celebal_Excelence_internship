from typing import Dict, List
from pydantic import BaseModel


class QuestionDifficultyBreakdown(BaseModel):
    easy: int = 0
    medium: int = 0
    hard: int = 0


class CategoryPerformance(BaseModel):
    category: str
    total_quizzes: int
    total_questions: int
    attempts_count: int
    average_score: float


class MostDifficultQuestion(BaseModel):
    question_id: int
    question_text: str
    category: str
    difficulty: str
    total_attempts: int
    wrong_percentage: float


class AdminDashboardAnalytics(BaseModel):
    total_users: int
    total_questions: int
    total_choices: int
    total_quizzes: int
    total_attempts: int
    average_score: float
    pass_percentage: float
    difficulty_breakdown: QuestionDifficultyBreakdown
    category_wise_performance: List[CategoryPerformance]
    daily_attempts_count: int
    weekly_attempts_count: int
    monthly_attempts_count: int
    user_growth_trend: Dict[str, int]
    most_attempted_quiz: Dict[str, str]
    most_popular_categories: List[Dict[str, int]]
    most_difficult_questions: List[MostDifficultQuestion]
