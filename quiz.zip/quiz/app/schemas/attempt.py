from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel, ConfigDict, Field
from app.schemas.question import QuestionResponse


class SingleAnswerSubmit(BaseModel):
    question_id: int = Field(..., example=1)
    selected_choice_id: Optional[int] = Field(None, example=4)


class QuizAttemptStartResponse(BaseModel):
    attempt_id: int
    user_id: int
    quiz_id: int
    quiz_title: str
    duration_minutes: int
    start_time: datetime
    expected_end_time: datetime
    questions: List[QuestionResponse]

    model_config = ConfigDict(from_attributes=True)


class QuizAttemptTimerResponse(BaseModel):
    attempt_id: int
    start_time: datetime
    expected_end_time: datetime
    current_time: datetime
    remaining_seconds: int
    is_expired: bool
    submitted: bool


class QuizAttemptSubmitRequest(BaseModel):
    answers: List[SingleAnswerSubmit] = Field(..., description="List of user selected answers")


class UserAnswerDetail(BaseModel):
    question_id: int
    question_text: str
    selected_choice_id: Optional[int]
    selected_choice_text: Optional[str]
    correct_choice_id: Optional[int]
    correct_choice_text: Optional[str]
    is_correct: bool
    explanation: Optional[str]


class QuizAttemptReportResponse(BaseModel):
    attempt_id: int
    user_id: int
    quiz_id: int
    quiz_title: str
    score: float
    total_marks: float
    percentage: float
    submitted: bool
    start_time: datetime
    end_time: Optional[datetime]
    total_questions: int
    correct_count: int
    wrong_count: int
    unanswered_count: int
    details: List[UserAnswerDetail] = []

    model_config = ConfigDict(from_attributes=True)


class UserScoreSummary(BaseModel):
    user_id: int
    total_attempts: int
    highest_score: float
    average_score: float
    correct_answers_count: int
    wrong_answers_count: int
    overall_accuracy_percentage: float
    category_scores: dict
    quiz_scores: dict
