from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel, ConfigDict, Field
from app.models.question import DifficultyLevel
from app.schemas.question import QuestionResponse


class QuizBase(BaseModel):
    title: str = Field(..., min_length=3, max_length=255, example="Python Fundamentals Master Quiz")
    description: str = Field(..., min_length=5, example="Test your knowledge of Python basics, data structures, and OOP.")
    category: str = Field(..., min_length=2, max_length=100, example="Programming")
    duration: int = Field(..., ge=1, le=300, example=15, description="Duration in minutes")
    total_marks: int = Field(default=100, ge=1, example=100)


class QuizCreate(QuizBase):
    question_ids: Optional[List[int]] = Field(default=[], description="List of question IDs to attach to quiz")


class QuizUpdate(BaseModel):
    title: Optional[str] = Field(None, min_length=3, max_length=255)
    description: Optional[str] = Field(None, min_length=5)
    category: Optional[str] = Field(None, min_length=2, max_length=100)
    duration: Optional[int] = Field(None, ge=1, le=300)
    total_marks: Optional[int] = Field(None, ge=1)


class AssignQuestionsRequest(BaseModel):
    question_ids: List[int] = Field(..., min_items=1, example=[1, 2, 3])


class QuizResponse(QuizBase):
    id: int
    created_at: datetime
    question_count: int = 0
    questions: List[QuestionResponse] = []

    model_config = ConfigDict(from_attributes=True)


class RandomQuizGenerateRequest(BaseModel):
    title: str = Field(..., min_length=3, max_length=255)
    description: str = Field(..., min_length=5)
    category: str = Field(..., min_length=2, max_length=100)
    num_questions: int = Field(default=10, ge=1, le=50)
    duration: int = Field(default=15, ge=1, le=300)


class CategoryQuizGenerateRequest(BaseModel):
    title: str = Field(..., min_length=3, max_length=255)
    description: str = Field(..., min_length=5)
    category: str = Field(..., min_length=2, max_length=100)
    num_questions: int = Field(default=10, ge=1, le=50)
    duration: int = Field(default=15, ge=1, le=300)


class DifficultyQuizGenerateRequest(BaseModel):
    title: str = Field(..., min_length=3, max_length=255)
    description: str = Field(..., min_length=5)
    difficulty: DifficultyLevel = Field(..., example="medium")
    category: Optional[str] = Field(None, example="Programming")
    num_questions: int = Field(default=10, ge=1, le=50)
    duration: int = Field(default=15, ge=1, le=300)


class MixedQuizGenerateRequest(BaseModel):
    title: str = Field(..., min_length=3, max_length=255)
    description: str = Field(..., min_length=5)
    category: Optional[str] = Field(None)
    num_easy: int = Field(default=3, ge=0)
    num_medium: int = Field(default=4, ge=0)
    num_hard: int = Field(default=3, ge=0)
    duration: int = Field(default=15, ge=1, le=300)
