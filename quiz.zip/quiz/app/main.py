from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.config import settings
from app.database import engine
from app.models.base import Base
from app.core.exceptions import CustomAPIException, custom_exception_handler, global_exception_handler
from app.routers import (
    auth_router, users_router, questions_router, choices_router,
    quizzes_router, attempts_router, leaderboard_router,
    analytics_router, recommendations_router
)
from app.utils.logger import logger


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup and shutdown lifecycle manager."""
    logger.info("Initializing Quiz Backend Management System database tables...")
    Base.metadata.create_all(bind=engine)
    logger.info("Database tables initialized successfully.")
    yield
    logger.info("Shutting down Quiz Backend Management System...")


app = FastAPI(
    title=settings.PROJECT_NAME,
    version=settings.VERSION,
    description="""
    ## Quiz Backend Management System RESTful API

    Production-ready backend built with FastAPI, SQLAlchemy, Pydantic v2, JWT Auth,
    Scikit-Learn Recommendation Engine, Analytics Dashboard, and Quiz Timer Engine.

    ### Domain Features Supported:
    - **Authentication**: JWT Access & Refresh Tokens with Role-Based Access Control (Admin / Student)
    - **Questions & Choices**: Full CRUD with cascading deletions, filtering, search, and pagination
    - **Quiz Management**: Manual & Automated Generators (Random, Category, Difficulty, Mixed)
    - **Timer & Attempts**: Countdown calculations, remaining time, auto-submit & timeout prevention
    - **Leaderboard**: Global, Quiz, Weekly, and Monthly rankings
    - **Analytics**: Admin metrics & Student progress metrics
    - **Recommendation System**: AI recommendation engine powered by Scikit-Learn TF-IDF & Cosine Similarity
    """,
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url=f"{settings.API_V1_STR}/openapi.json",
    lifespan=lifespan
)

# Configure CORS Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.BACKEND_CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register Exception Handlers
app.add_exception_handler(CustomAPIException, custom_exception_handler)
app.add_exception_handler(Exception, global_exception_handler)

# Include API Routers under /api/v1 prefix
api_v1_prefix = settings.API_V1_STR
app.include_router(auth_router, prefix=api_v1_prefix)
app.include_router(users_router, prefix=api_v1_prefix)
app.include_router(questions_router, prefix=api_v1_prefix)
app.include_router(choices_router, prefix=api_v1_prefix)
app.include_router(quizzes_router, prefix=api_v1_prefix)
app.include_router(attempts_router, prefix=api_v1_prefix)
app.include_router(leaderboard_router, prefix=api_v1_prefix)
app.include_router(analytics_router, prefix=api_v1_prefix)
app.include_router(recommendations_router, prefix=api_v1_prefix)


@app.get("/", tags=["System Check"])
def root_check():
    """Root status endpoint returning service status and documentation link."""
    return {
        "status": "online",
        "service": settings.PROJECT_NAME,
        "version": settings.VERSION,
        "docs": "/docs",
        "api_v1": settings.API_V1_STR
    }
