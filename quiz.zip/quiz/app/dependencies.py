from typing import Generator, Optional
from fastapi import Depends, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session
from app.database import get_db
from app.core.security import decode_token
from app.core.exceptions import UnauthorizedException, ForbiddenException
from app.models.user import User, UserRole
from app.crud.crud_user import crud_user

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/v1/auth/login")


def get_current_user(
    db: Session = Depends(get_db),
    token: str = Depends(oauth2_scheme)
) -> User:
    """Extracts user from JWT token."""
    payload = decode_token(token)
    if not payload or payload.get("type") != "access":
        raise UnauthorizedException("Invalid or expired access token")

    user_id = payload.get("sub")
    if not user_id:
        raise UnauthorizedException("Token missing subject identifier")

    user = crud_user.get_by_id(db, int(user_id))
    if not user:
        raise UnauthorizedException("User no longer exists")

    return user


def require_admin(
    current_user: User = Depends(get_current_user)
) -> User:
    """Enforces Admin role permission guard."""
    if current_user.role != UserRole.ADMIN:
        raise ForbiddenException("Administrator privileges required for this action")
    return current_user


def require_student_or_admin(
    current_user: User = Depends(get_current_user)
) -> User:
    """Allows authenticated students or admins."""
    return current_user
