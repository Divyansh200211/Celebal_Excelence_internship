from typing import List, Optional
from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.orm import Session
from app.database import get_db
from app.schemas.question import ChoiceCreate, ChoiceUpdate, ChoiceResponse
from app.schemas.common import GenericMessageResponse
from app.crud.crud_question import crud_question
from app.dependencies import get_current_user, require_admin
from app.core.exceptions import NotFoundException

router = APIRouter(prefix="/choices", tags=["Choices CRUD"])


@router.post("", response_model=ChoiceResponse, status_code=status.HTTP_201_CREATED, dependencies=[Depends(require_admin)])
def create_choice_for_question(
    question_id: int = Query(..., description="ID of question to attach choice to"),
    obj_in: ChoiceCreate = ...,
    db: Session = Depends(get_db)
):
    """Adds a new choice option to an existing question [Admin only]."""
    question = crud_question.get_by_id(db, question_id)
    if not question:
        raise NotFoundException(f"Question with ID {question_id} not found.")
    choice = crud_question.add_choice(db, question_id, obj_in)
    return choice


@router.get("", response_model=List[ChoiceResponse], dependencies=[Depends(get_current_user)])
def list_choices(
    question_id: Optional[int] = Query(None, description="Filter choices by question_id"),
    db: Session = Depends(get_db)
):
    """Lists choices, optionally filtered by question_id."""
    if question_id:
        return crud_question.get_choices_for_question(db, question_id)
    # Return choices across system
    questions, _ = crud_question.get_multi(db, page=1, page_size=100)
    all_choices = []
    for q in questions:
        all_choices.extend(q.choices)
    return all_choices


@router.put("/{choice_id}", response_model=ChoiceResponse, dependencies=[Depends(require_admin)])
def update_choice(
    choice_id: int,
    obj_in: ChoiceUpdate,
    db: Session = Depends(get_db)
):
    """Updates choice text or correctness flag [Admin only]."""
    choice = crud_question.get_choice_by_id(db, choice_id)
    if not choice:
        raise NotFoundException(f"Choice with ID {choice_id} not found.")
    updated_choice = crud_question.update_choice(db, choice, obj_in)
    return updated_choice


@router.delete("/{choice_id}", response_model=GenericMessageResponse, dependencies=[Depends(require_admin)])
def delete_choice(choice_id: int, db: Session = Depends(get_db)):
    """Deletes choice by ID [Admin only]."""
    success = crud_question.delete_choice(db, choice_id)
    if not success:
        raise NotFoundException(f"Choice with ID {choice_id} not found.")
    return GenericMessageResponse(message=f"Choice {choice_id} deleted successfully.")
