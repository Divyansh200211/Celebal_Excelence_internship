from typing import Optional
from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.orm import Session
from app.database import get_db
from app.schemas.quiz import (
    QuizCreate, QuizUpdate, QuizResponse, AssignQuestionsRequest,
    RandomQuizGenerateRequest, CategoryQuizGenerateRequest,
    DifficultyQuizGenerateRequest, MixedQuizGenerateRequest
)
from app.schemas.common import PaginatedResponse, GenericMessageResponse
from app.crud.crud_quiz import crud_quiz
from app.services.quiz_service import quiz_service
from app.dependencies import get_current_user, require_admin
from app.core.exceptions import NotFoundException

router = APIRouter(prefix="/quizzes", tags=["Quiz Management"])


@router.post("", response_model=QuizResponse, status_code=status.HTTP_201_CREATED, dependencies=[Depends(require_admin)])
def create_quiz(obj_in: QuizCreate, db: Session = Depends(get_db)):
    """Creates a new quiz [Admin only]."""
    quiz = crud_quiz.create(db, obj_in)
    q_resp = QuizResponse.model_validate(quiz)
    q_resp.question_count = len(quiz.quiz_questions)
    q_resp.questions = crud_quiz.get_quiz_questions(db, quiz.id)
    return q_resp


@router.get("", response_model=PaginatedResponse[QuizResponse], dependencies=[Depends(get_current_user)])
def list_quizzes(
    page: int = Query(1, ge=1),
    page_size: int = Query(10, ge=1, le=100),
    category: Optional[str] = Query(None, description="Filter by category"),
    search: Optional[str] = Query(None, description="Search title or description"),
    db: Session = Depends(get_db)
):
    """Lists quizzes with pagination, category filtering, and keyword search."""
    quizzes, total = crud_quiz.get_multi(db, page=page, page_size=page_size, category=category, search=search)
    total_pages = (total + page_size - 1) // page_size if total > 0 else 1

    items = []
    for q in quizzes:
        q_resp = QuizResponse.model_validate(q)
        q_resp.question_count = len(q.quiz_questions)
        items.append(q_resp)

    return PaginatedResponse[QuizResponse](
        items=items,
        total=total,
        page=page,
        page_size=page_size,
        total_pages=total_pages
    )


@router.get("/{quiz_id}", response_model=QuizResponse, dependencies=[Depends(get_current_user)])
def get_quiz_by_id(quiz_id: int, db: Session = Depends(get_db)):
    """Retrieves quiz details along with attached question list."""
    quiz = crud_quiz.get_by_id(db, quiz_id)
    if not quiz:
        raise NotFoundException(f"Quiz with ID {quiz_id} not found.")

    q_resp = QuizResponse.model_validate(quiz)
    q_resp.question_count = len(quiz.quiz_questions)
    q_resp.questions = crud_quiz.get_quiz_questions(db, quiz.id)
    return q_resp


@router.put("/{quiz_id}", response_model=QuizResponse, dependencies=[Depends(require_admin)])
def update_quiz(quiz_id: int, obj_in: QuizUpdate, db: Session = Depends(get_db)):
    """Updates quiz details [Admin only]."""
    quiz = crud_quiz.get_by_id(db, quiz_id)
    if not quiz:
        raise NotFoundException(f"Quiz with ID {quiz_id} not found.")

    updated_quiz = crud_quiz.update(db, quiz, obj_in)
    q_resp = QuizResponse.model_validate(updated_quiz)
    q_resp.question_count = len(updated_quiz.quiz_questions)
    q_resp.questions = crud_quiz.get_quiz_questions(db, updated_quiz.id)
    return q_resp


@router.delete("/{quiz_id}", response_model=GenericMessageResponse, dependencies=[Depends(require_admin)])
def delete_quiz(quiz_id: int, db: Session = Depends(get_db)):
    """Deletes quiz [Admin only]."""
    success = crud_quiz.delete(db, quiz_id)
    if not success:
        raise NotFoundException(f"Quiz with ID {quiz_id} not found.")
    return GenericMessageResponse(message=f"Quiz {quiz_id} deleted successfully.")


@router.post("/{quiz_id}/questions", response_model=QuizResponse, dependencies=[Depends(require_admin)])
def assign_questions_to_quiz(quiz_id: int, req: AssignQuestionsRequest, db: Session = Depends(get_db)):
    """Assigns list of question IDs to quiz [Admin only]."""
    quiz = crud_quiz.assign_questions(db, quiz_id, req.question_ids)
    if not quiz:
        raise NotFoundException(f"Quiz with ID {quiz_id} not found.")

    q_resp = QuizResponse.model_validate(quiz)
    q_resp.question_count = len(quiz.quiz_questions)
    q_resp.questions = crud_quiz.get_quiz_questions(db, quiz.id)
    return q_resp


@router.delete("/{quiz_id}/questions/{question_id}", response_model=GenericMessageResponse, dependencies=[Depends(require_admin)])
def remove_question_from_quiz(quiz_id: int, question_id: int, db: Session = Depends(get_db)):
    """Removes a question association from quiz [Admin only]."""
    success = crud_quiz.remove_question(db, quiz_id, question_id)
    if not success:
        raise NotFoundException(f"Question {question_id} is not attached to Quiz {quiz_id}.")
    return GenericMessageResponse(message=f"Question {question_id} removed from Quiz {quiz_id} successfully.")


# Quiz Generators
@router.post("/generate/random", response_model=QuizResponse, status_code=status.HTTP_201_CREATED, dependencies=[Depends(require_admin)])
def generate_random_quiz(req: RandomQuizGenerateRequest, db: Session = Depends(get_db)):
    """Generates a random quiz based on count [Admin only]."""
    quiz = quiz_service.generate_random_quiz(db, req)
    q_resp = QuizResponse.model_validate(quiz)
    q_resp.question_count = len(quiz.quiz_questions)
    q_resp.questions = crud_quiz.get_quiz_questions(db, quiz.id)
    return q_resp


@router.post("/generate/category", response_model=QuizResponse, status_code=status.HTTP_201_CREATED, dependencies=[Depends(require_admin)])
def generate_category_quiz(req: CategoryQuizGenerateRequest, db: Session = Depends(get_db)):
    """Generates a category-wise quiz [Admin only]."""
    quiz = quiz_service.generate_category_quiz(db, req)
    q_resp = QuizResponse.model_validate(quiz)
    q_resp.question_count = len(quiz.quiz_questions)
    q_resp.questions = crud_quiz.get_quiz_questions(db, quiz.id)
    return q_resp


@router.post("/generate/difficulty", response_model=QuizResponse, status_code=status.HTTP_201_CREATED, dependencies=[Depends(require_admin)])
def generate_difficulty_quiz(req: DifficultyQuizGenerateRequest, db: Session = Depends(get_db)):
    """Generates a difficulty-wise quiz (Easy, Medium, Hard) [Admin only]."""
    quiz = quiz_service.generate_difficulty_quiz(db, req)
    q_resp = QuizResponse.model_validate(quiz)
    q_resp.question_count = len(quiz.quiz_questions)
    q_resp.questions = crud_quiz.get_quiz_questions(db, quiz.id)
    return q_resp


@router.post("/generate/mixed", response_model=QuizResponse, status_code=status.HTTP_201_CREATED, dependencies=[Depends(require_admin)])
def generate_mixed_quiz(req: MixedQuizGenerateRequest, db: Session = Depends(get_db)):
    """Generates a balanced mixed-difficulty quiz [Admin only]."""
    quiz = quiz_service.generate_mixed_quiz(db, req)
    q_resp = QuizResponse.model_validate(quiz)
    q_resp.question_count = len(quiz.quiz_questions)
    q_resp.questions = crud_quiz.get_quiz_questions(db, quiz.id)
    return q_resp
