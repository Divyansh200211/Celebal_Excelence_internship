from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.orm import Session
from app.database import get_db
from app.schemas.user import UserResponse, UserUpdate
from app.schemas.common import PaginatedResponse
from app.crud.crud_user import crud_user
from app.dependencies import require_admin
from app.models.user import User
from app.core.exceptions import NotFoundException

router = APIRouter(prefix="/users", tags=["Users Management"])


@router.get("", response_model=PaginatedResponse[UserResponse], dependencies=[Depends(require_admin)])
def list_users(
    page: int = Query(1, ge=1),
    page_size: int = Query(10, ge=1, le=100),
    db: Session = Depends(get_db)
):
    """Lists registered users with pagination [Admin only]."""
    users, total = crud_user.get_multi(db, page=page, page_size=page_size)
    total_pages = (total + page_size - 1) // page_size if total > 0 else 1
    return PaginatedResponse[UserResponse](
        items=[UserResponse.model_validate(u) for u in users],
        total=total,
        page=page,
        page_size=page_size,
        total_pages=total_pages
    )


@router.get("/{user_id}", response_model=UserResponse, dependencies=[Depends(require_admin)])
def get_user_by_id(user_id: int, db: Session = Depends(get_db)):
    """Retrieves user details by ID [Admin only]."""
    user = crud_user.get_by_id(db, user_id)
    if not user:
        raise NotFoundException(f"User with ID {user_id} not found.")
    return user


@router.put("/{user_id}", response_model=UserResponse, dependencies=[Depends(require_admin)])
def update_user(user_id: int, obj_in: UserUpdate, db: Session = Depends(get_db)):
    """Updates user role or details [Admin only]."""
    user = crud_user.get_by_id(db, user_id)
    if not user:
        raise NotFoundException(f"User with ID {user_id} not found.")
    updated_user = crud_user.update(db, user, obj_in)
    return updated_user
