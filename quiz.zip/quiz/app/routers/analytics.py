from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.database import get_db
from app.schemas.analytics import AdminDashboardAnalytics
from app.schemas.attempt import UserScoreSummary
from app.services.analytics_service import analytics_service
from app.dependencies import get_current_user, require_admin
from app.models.user import User

router = APIRouter(prefix="/analytics", tags=["Analytics Dashboard"])


@router.get("/admin-dashboard", response_model=AdminDashboardAnalytics, dependencies=[Depends(require_admin)])
def get_admin_dashboard(db: Session = Depends(get_db)):
    """
    Returns comprehensive system metrics for Admin Dashboard [Admin only].
    Includes total users, questions, quizzes, attempts, average score,
    pass percentage, category performance, daily/weekly/monthly attempts,
    most attempted quiz, and most difficult questions.
    """
    return analytics_service.get_admin_dashboard_metrics(db)


@router.get("/user-dashboard", response_model=UserScoreSummary)
def get_user_dashboard(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Returns personal analytics summary for logged-in user.
    Includes highest score, average score, total attempts, correct/wrong counts,
    and category-wise accuracy breakdown.
    """
    return analytics_service.get_user_score_summary(db, current_user.id)
