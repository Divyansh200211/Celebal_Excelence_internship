from typing import Optional
from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.orm import Session
from app.database import get_db
from app.schemas.question import QuestionCreate, QuestionUpdate, QuestionResponse
from app.schemas.common import PaginatedResponse, GenericMessageResponse
from app.crud.crud_question import crud_question
from app.dependencies import get_current_user, require_admin
from app.models.user import User
from app.models.question import DifficultyLevel
from app.core.exceptions import NotFoundException, BadRequestException

router = APIRouter(prefix="/questions", tags=["Questions CRUD"])


@router.post("", response_model=QuestionResponse, status_code=status.HTTP_201_CREATED, dependencies=[Depends(require_admin)])
def create_question(
    obj_in: QuestionCreate,
    db: Session = Depends(get_db)
):
    """
    Creates a new question with choices [Admin only].
    Validates at least one choice is flagged as correct.
    """
    has_correct = any(c.is_correct for c in obj_in.choices)
    if not has_correct:
        raise BadRequestException("At least one choice must be marked as correct (is_correct = true).")

    question = crud_question.create(db, obj_in)
    return question


@router.get("", response_model=PaginatedResponse[QuestionResponse], dependencies=[Depends(get_current_user)])
def list_questions(
    page: int = Query(1, ge=1),
    page_size: int = Query(10, ge=1, le=100),
    category: Optional[str] = Query(None, description="Filter by category"),
    difficulty: Optional[DifficultyLevel] = Query(None, description="Filter by difficulty"),
    search: Optional[str] = Query(None, description="Search question text or explanation"),
    db: Session = Depends(get_db)
):
    """
    Lists questions with pagination, category/difficulty filtering, and keyword search.
    Accessible by authenticated users.
    """
    questions, total = crud_question.get_multi(
        db,
        page=page,
        page_size=page_size,
        category=category,
        difficulty=difficulty,
        search=search
    )
    total_pages = (total + page_size - 1) // page_size if total > 0 else 1
    return PaginatedResponse[QuestionResponse](
        items=[QuestionResponse.model_validate(q) for q in questions],
        total=total,
        page=page,
        page_size=page_size,
        total_pages=total_pages
    )


@router.get("/{question_id}", response_model=QuestionResponse, dependencies=[Depends(get_current_user)])
def get_question_by_id(question_id: int, db: Session = Depends(get_db)):
    """Retrieves single question details with choice options."""
    question = crud_question.get_by_id(db, question_id)
    if not question:
        raise NotFoundException(f"Question with ID {question_id} not found.")
    return question


@router.put("/{question_id}", response_model=QuestionResponse, dependencies=[Depends(require_admin)])
def update_question(
    question_id: int,
    obj_in: QuestionUpdate,
    db: Session = Depends(get_db)
):
    """Updates question details [Admin only]."""
    question = crud_question.get_by_id(db, question_id)
    if not question:
        raise NotFoundException(f"Question with ID {question_id} not found.")
    updated_question = crud_question.update(db, question, obj_in)
    return updated_question


@router.delete("/{question_id}", response_model=GenericMessageResponse, dependencies=[Depends(require_admin)])
def delete_question(question_id: int, db: Session = Depends(get_db)):
    """
    Deletes question by ID [Admin only].
    Cascading delete automatically removes all associated answer choices.
    """
    success = crud_question.delete(db, question_id)
    if not success:
        raise NotFoundException(f"Question with ID {question_id} not found.")
    return GenericMessageResponse(message=f"Question {question_id} and associated choices deleted successfully.")
