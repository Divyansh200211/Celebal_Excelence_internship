from fastapi import APIRouter, Depends, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session

from app.database import get_db
from app.schemas.user import UserCreate, UserResponse, TokenResponse, TokenRefreshRequest
from app.crud.crud_user import crud_user
from app.core.security import verify_password, create_access_token, create_refresh_token, decode_token
from app.core.exceptions import ConflictException, UnauthorizedException, BadRequestException
from app.dependencies import get_current_user
from app.models.user import User
from app.utils.logger import logger

router = APIRouter(prefix="/auth", tags=["Authentication"])


@router.post("/register", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
def register_user(user_in: UserCreate, db: Session = Depends(get_db)):
    """Registers a new user (Admin or Student)."""
    if crud_user.get_by_email(db, user_in.email):
        raise ConflictException(f"Email {user_in.email} is already registered.")

    if crud_user.get_by_username(db, user_in.username):
        raise ConflictException(f"Username '{user_in.username}' is already taken.")

    user = crud_user.create(db, user_in)
    logger.info(f"New user registered: {user.username} (Role: {user.role})")
    return user


@router.post("/login", response_model=TokenResponse)
def login(
    form_data: OAuth2PasswordRequestForm = Depends(),
    db: Session = Depends(get_db)
):
    """OAuth2 password login returning JWT access and refresh tokens."""
    user = crud_user.get_by_username_or_email(db, form_data.username)
    if not user or not verify_password(form_data.password, user.password_hash):
        raise UnauthorizedException("Incorrect username/email or password.")

    access_token = create_access_token(subject=user.id, role=user.role.value)
    refresh_token = create_refresh_token(subject=user.id, role=user.role.value)

    logger.info(f"User logged in successfully: {user.username}")
    return TokenResponse(
        access_token=access_token,
        refresh_token=refresh_token,
        user=UserResponse.model_validate(user)
    )


@router.post("/refresh", response_model=TokenResponse)
def refresh_token(req: TokenRefreshRequest, db: Session = Depends(get_db)):
    """Generates a new access token using a valid refresh token."""
    payload = decode_token(req.refresh_token)
    if not payload or payload.get("type") != "refresh":
        raise UnauthorizedException("Invalid or expired refresh token.")

    user_id = payload.get("sub")
    user = crud_user.get_by_id(db, int(user_id))
    if not user:
        raise UnauthorizedException("User no longer exists.")

    new_access_token = create_access_token(subject=user.id, role=user.role.value)
    new_refresh_token = create_refresh_token(subject=user.id, role=user.role.value)

    return TokenResponse(
        access_token=new_access_token,
        refresh_token=new_refresh_token,
        user=UserResponse.model_validate(user)
    )


@router.get("/me", response_model=UserResponse)
def get_me(current_user: User = Depends(get_current_user)):
    """Returns profile information for current authenticated user."""
    return current_user
