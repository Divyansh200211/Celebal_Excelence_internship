from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from app.database import get_db
from app.schemas.recommendation import RecommendationListResponse
from app.services.recommendation_service import recommendation_engine
from app.dependencies import get_current_user, require_admin
from app.models.user import User

router = APIRouter(prefix="/recommendations", tags=["Quiz Recommendation Engine"])


@router.get("", response_model=RecommendationListResponse)
def get_my_recommendations(
    top_n: int = Query(5, ge=1, le=20),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Returns AI personalized quiz recommendations for logged-in user using Scikit-Learn.
    Considers past performance, weak categories, unattempted quizzes, and difficulty progression.
    """
    return recommendation_engine.recommend_quizzes_for_user(db, current_user.id, top_n=top_n)


@router.get("/{user_id}", response_model=RecommendationListResponse, dependencies=[Depends(require_admin)])
def get_user_recommendations(
    user_id: int,
    top_n: int = Query(5, ge=1, le=20),
    db: Session = Depends(get_db)
):
    """Returns AI recommendations for a specific user ID [Admin only]."""
    return recommendation_engine.recommend_quizzes_for_user(db, user_id, top_n=top_n)
