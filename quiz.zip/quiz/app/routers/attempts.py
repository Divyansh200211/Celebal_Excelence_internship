from datetime import datetime, timezone
from typing import List, Optional
from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.orm import Session
from app.database import get_db
from app.schemas.attempt import (
    QuizAttemptStartResponse, QuizAttemptTimerResponse, QuizAttemptSubmitRequest,
    QuizAttemptReportResponse, UserAnswerDetail
)
from app.schemas.common import PaginatedResponse
from app.crud.crud_quiz import crud_quiz
from app.crud.crud_attempt import crud_attempt
from app.services.timer_service import timer_service
from app.services.quiz_service import quiz_service
from app.dependencies import get_current_user
from app.models.user import User
from app.models.question import Choice
from app.core.exceptions import NotFoundException, BadRequestException, ForbiddenException
from app.utils.logger import logger

router = APIRouter(prefix="/attempts", tags=["Quiz Attempts & Timer"])


@router.post("/start/{quiz_id}", response_model=QuizAttemptStartResponse, status_code=status.HTTP_201_CREATED)
def start_quiz_attempt(
    quiz_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Starts a new quiz attempt for current student.
    Initiates backend countdown timer and returns attached questions.
    """
    quiz = crud_quiz.get_by_id(db, quiz_id)
    if not quiz:
        raise NotFoundException(f"Quiz with ID {quiz_id} not found.")

    questions = crud_quiz.get_quiz_questions(db, quiz_id)
    if not questions:
        raise BadRequestException(f"Quiz '{quiz.title}' does not have any attached questions.")

    # Check if there is an existing un-submitted active attempt
    active_attempt = crud_attempt.get_active_attempt(db, current_user.id, quiz_id)
    if active_attempt:
        expected_end, _, is_expired = timer_service.get_timer_status(active_attempt, quiz)
        if not is_expired:
            return QuizAttemptStartResponse(
                attempt_id=active_attempt.id,
                user_id=current_user.id,
                quiz_id=quiz.id,
                quiz_title=quiz.title,
                duration_minutes=quiz.duration,
                start_time=active_attempt.start_time,
                expected_end_time=expected_end,
                questions=questions
            )

    # Create new attempt
    attempt = crud_attempt.create_attempt(db, current_user.id, quiz_id)
    expected_end, _, _ = timer_service.get_timer_status(attempt, quiz)

    logger.info(f"User {current_user.username} started quiz attempt {attempt.id} (Quiz: {quiz.title})")
    return QuizAttemptStartResponse(
        attempt_id=attempt.id,
        user_id=current_user.id,
        quiz_id=quiz.id,
        quiz_title=quiz.title,
        duration_minutes=quiz.duration,
        start_time=attempt.start_time,
        expected_end_time=expected_end,
        questions=questions
    )


@router.get("/{attempt_id}/timer", response_model=QuizAttemptTimerResponse)
def get_remaining_timer(
    attempt_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Returns remaining seconds and timeout expiration status for active attempt."""
    attempt = crud_attempt.get_by_id(db, attempt_id)
    if not attempt:
        raise NotFoundException(f"Attempt with ID {attempt_id} not found.")

    if attempt.user_id != current_user.id and current_user.role != "admin":
        raise ForbiddenException("You cannot view timer for another user's attempt.")

    quiz = crud_quiz.get_by_id(db, attempt.quiz_id)
    expected_end, remaining_seconds, is_expired = timer_service.get_timer_status(attempt, quiz)

    return QuizAttemptTimerResponse(
        attempt_id=attempt.id,
        start_time=attempt.start_time,
        expected_end_time=expected_end,
        current_time=datetime.now(timezone.utc),
        remaining_seconds=remaining_seconds,
        is_expired=is_expired,
        submitted=attempt.submitted
    )


@router.post("/{attempt_id}/submit", response_model=QuizAttemptReportResponse)
def submit_quiz_attempt(
    attempt_id: int,
    req: QuizAttemptSubmitRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Submits user answers for evaluation and computes score.
    Prevents submission if timer has expired.
    """
    attempt = crud_attempt.get_by_id(db, attempt_id)
    if not attempt:
        raise NotFoundException(f"Attempt with ID {attempt_id} not found.")

    if attempt.user_id != current_user.id:
        raise ForbiddenException("You can only submit your own quiz attempt.")

    if attempt.submitted:
        raise BadRequestException("This attempt has already been submitted.")

    quiz = crud_quiz.get_by_id(db, attempt.quiz_id)
    _, _, is_expired = timer_service.get_timer_status(attempt, quiz)
    if is_expired:
        # Prevent manual submission after timeout and trigger auto-submit evaluate
        logger.warning(f"Submission rejected after timer expiry for attempt {attempt_id}.")
        raise BadRequestException("Quiz timer has expired! Submission rejected.")

    # Evaluate submission
    submitted_dict_list = [a.model_dump() for a in req.answers]
    score, percentage, saved_answers = quiz_service.evaluate_attempt_submission(
        db, attempt, quiz, submitted_dict_list
    )

    logger.info(f"Quiz attempt {attempt_id} submitted. Score: {score}/{quiz.total_marks} ({percentage}%)")
    return get_attempt_report(attempt_id, current_user, db)


@router.post("/{attempt_id}/auto-submit", response_model=QuizAttemptReportResponse)
def auto_submit_quiz_attempt(
    attempt_id: int,
    req: QuizAttemptSubmitRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Auto-submits attempt upon frontend countdown expiration."""
    attempt = crud_attempt.get_by_id(db, attempt_id)
    if not attempt:
        raise NotFoundException(f"Attempt with ID {attempt_id} not found.")

    if attempt.submitted:
        return get_attempt_report(attempt_id, current_user, db)

    quiz = crud_quiz.get_by_id(db, attempt.quiz_id)
    submitted_dict_list = [a.model_dump() for a in req.answers]
    score, percentage, _ = quiz_service.evaluate_attempt_submission(
        db, attempt, quiz, submitted_dict_list
    )

    logger.info(f"Attempt {attempt_id} auto-submitted due to timer expiration. Score: {score}")
    return get_attempt_report(attempt_id, current_user, db)


@router.get("/my-attempts", response_model=PaginatedResponse[QuizAttemptReportResponse])
def list_my_attempts(
    page: int = Query(1, ge=1),
    page_size: int = Query(10, ge=1, le=100),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Lists current student's historical attempts."""
    attempts, total = crud_attempt.get_user_attempts(db, current_user.id, page=page, page_size=page_size)
    total_pages = (total + page_size - 1) // page_size if total > 0 else 1

    reports = [get_attempt_report(a.id, current_user, db) for a in attempts]

    return PaginatedResponse[QuizAttemptReportResponse](
        items=reports,
        total=total,
        page=page,
        page_size=page_size,
        total_pages=total_pages
    )


@router.get("/{attempt_id}/report", response_model=QuizAttemptReportResponse)
def get_attempt_report(
    attempt_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Retrieves detailed evaluation report for a completed attempt."""
    attempt = crud_attempt.get_by_id(db, attempt_id)
    if not attempt:
        raise NotFoundException(f"Attempt with ID {attempt_id} not found.")

    if attempt.user_id != current_user.id and current_user.role != "admin":
        raise ForbiddenException("You cannot view report for another user's attempt.")

    quiz = crud_quiz.get_by_id(db, attempt.quiz_id)
    questions = crud_quiz.get_quiz_questions(db, quiz.id)

    user_answers_map = {ua.question_id: ua for ua in attempt.user_answers}

    details = []
    correct_cnt = 0
    wrong_cnt = 0
    unanswered_cnt = 0

    for q in questions:
        ua = user_answers_map.get(q.id)
        selected_choice_id = ua.selected_choice_id if ua else None
        is_corr = ua.is_correct if ua else False

        selected_choice = db.query(Choice).filter(Choice.id == selected_choice_id).first() if selected_choice_id else None
        correct_choice = db.query(Choice).filter(Choice.question_id == q.id, Choice.is_correct == True).first()

        if selected_choice_id is None:
            unanswered_cnt += 1
        elif is_corr:
            correct_cnt += 1
        else:
            wrong_cnt += 1

        details.append(UserAnswerDetail(
            question_id=q.id,
            question_text=q.question_text,
            selected_choice_id=selected_choice_id,
            selected_choice_text=selected_choice.choice_text if selected_choice else None,
            correct_choice_id=correct_choice.id if correct_choice else None,
            correct_choice_text=correct_choice.choice_text if correct_choice else None,
            is_correct=is_corr,
            explanation=q.explanation
        ))

    return QuizAttemptReportResponse(
        attempt_id=attempt.id,
        user_id=attempt.user_id,
        quiz_id=quiz.id,
        quiz_title=quiz.title,
        score=attempt.score,
        total_marks=quiz.total_marks,
        percentage=attempt.percentage,
        submitted=attempt.submitted,
        start_time=attempt.start_time,
        end_time=attempt.end_time,
        total_questions=len(questions),
        correct_count=correct_cnt,
        wrong_count=wrong_cnt,
        unanswered_count=unanswered_cnt,
        details=details
    )
