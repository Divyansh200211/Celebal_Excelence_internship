from app.routers.auth import router as auth_router
from app.routers.users import router as users_router
from app.routers.questions import router as questions_router
from app.routers.choices import router as choices_router
from app.routers.quizzes import router as quizzes_router
from app.routers.attempts import router as attempts_router
from app.routers.leaderboard import router as leaderboard_router
from app.routers.analytics import router as analytics_router
from app.routers.recommendations import router as recommendations_router

__all__ = [
    "auth_router",
    "users_router",
    "questions_router",
    "choices_router",
    "quizzes_router",
    "attempts_router",
    "leaderboard_router",
    "analytics_router",
    "recommendations_router",
]
