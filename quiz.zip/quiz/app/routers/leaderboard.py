from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from app.database import get_db
from app.schemas.leaderboard import LeaderboardListResponse, LeaderboardEntryResponse
from app.crud.crud_leaderboard import crud_leaderboard
from app.crud.crud_quiz import crud_quiz
from app.dependencies import get_current_user
from app.core.exceptions import NotFoundException

router = APIRouter(prefix="/leaderboard", tags=["Leaderboard"])


@router.get("/global", response_model=LeaderboardListResponse, dependencies=[Depends(get_current_user)])
def get_global_leaderboard(
    limit: int = Query(10, ge=1, le=100),
    db: Session = Depends(get_db)
):
    """Retrieves top global users by total cumulative score."""
    entries_data = crud_leaderboard.get_global_leaderboard(db, limit=limit)
    entries = [LeaderboardEntryResponse(**item) for item in entries_data]
    return LeaderboardListResponse(
        title="Global Leaderboard - Top Rankings",
        total_entries=len(entries),
        entries=entries
    )


@router.get("/quiz/{quiz_id}", response_model=LeaderboardListResponse, dependencies=[Depends(get_current_user)])
def get_quiz_leaderboard(
    quiz_id: int,
    limit: int = Query(10, ge=1, le=100),
    db: Session = Depends(get_db)
):
    """Retrieves top scoring users for a specific quiz."""
    quiz = crud_quiz.get_by_id(db, quiz_id)
    if not quiz:
        raise NotFoundException(f"Quiz with ID {quiz_id} not found.")

    entries_data = crud_leaderboard.get_quiz_leaderboard(db, quiz_id, limit=limit)
    entries = [LeaderboardEntryResponse(**item) for item in entries_data]
    return LeaderboardListResponse(
        title=f"Leaderboard for '{quiz.title}'",
        total_entries=len(entries),
        entries=entries
    )


@router.get("/weekly", response_model=LeaderboardListResponse, dependencies=[Depends(get_current_user)])
def get_weekly_leaderboard(
    limit: int = Query(10, ge=1, le=100),
    db: Session = Depends(get_db)
):
    """Retrieves weekly leaderboard for performance in last 7 days."""
    entries_data = crud_leaderboard.get_timeframe_leaderboard(db, days=7, limit=limit)
    entries = [LeaderboardEntryResponse(**item) for item in entries_data]
    return LeaderboardListResponse(
        title="Weekly Leaderboard (Last 7 Days)",
        total_entries=len(entries),
        entries=entries
    )


@router.get("/monthly", response_model=LeaderboardListResponse, dependencies=[Depends(get_current_user)])
def get_monthly_leaderboard(
    limit: int = Query(10, ge=1, le=100),
    db: Session = Depends(get_db)
):
    """Retrieves monthly leaderboard for performance in last 30 days."""
    entries_data = crud_leaderboard.get_timeframe_leaderboard(db, days=30, limit=limit)
    entries = [LeaderboardEntryResponse(**item) for item in entries_data]
    return LeaderboardListResponse(
        title="Monthly Leaderboard (Last 30 Days)",
        total_entries=len(entries),
        entries=entries
    )
