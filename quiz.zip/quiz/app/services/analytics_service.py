from datetime import datetime, timedelta, timezone
from typing import Dict, List, Any
from sqlalchemy import func, case, desc
from sqlalchemy.orm import Session
from app.models.user import User, UserRole
from app.models.question import Question, Choice, DifficultyLevel
from app.models.quiz import Quiz
from app.models.attempt import QuizAttempt, UserAnswer
from app.models.leaderboard import Leaderboard
from app.schemas.analytics import AdminDashboardAnalytics, CategoryPerformance, QuestionDifficultyBreakdown, MostDifficultQuestion
from app.schemas.attempt import UserScoreSummary


class AnalyticsService:
    @staticmethod
    def get_admin_dashboard_metrics(db: Session) -> AdminDashboardAnalytics:
        now = datetime.now(timezone.utc)

        total_users = db.query(User).count()
        total_questions = db.query(Question).count()
        total_choices = db.query(Choice).count()
        total_quizzes = db.query(Quiz).count()
        total_attempts = db.query(QuizAttempt).filter(QuizAttempt.submitted == True).count()

        # Avg score & pass percentage (pass = percentage >= 50%)
        avg_score_query = db.query(func.avg(QuizAttempt.percentage)).filter(QuizAttempt.submitted == True).scalar()
        average_score = round(float(avg_score_query), 2) if avg_score_query is not None else 0.0

        passed_count = db.query(QuizAttempt).filter(QuizAttempt.submitted == True, QuizAttempt.percentage >= 50.0).count()
        pass_percentage = round((passed_count / float(total_attempts)) * 100.0, 2) if total_attempts > 0 else 0.0

        # Difficulty breakdown
        easy_cnt = db.query(Question).filter(Question.difficulty == DifficultyLevel.EASY).count()
        med_cnt = db.query(Question).filter(Question.difficulty == DifficultyLevel.MEDIUM).count()
        hard_cnt = db.query(Question).filter(Question.difficulty == DifficultyLevel.HARD).count()
        diff_breakdown = QuestionDifficultyBreakdown(easy=easy_cnt, medium=med_cnt, hard=hard_cnt)

        # Timeframe attempts count
        one_day_ago = now - timedelta(days=1)
        seven_days_ago = now - timedelta(days=7)
        thirty_days_ago = now - timedelta(days=30)

        daily_cnt = db.query(QuizAttempt).filter(QuizAttempt.submitted == True, QuizAttempt.start_time >= one_day_ago).count()
        weekly_cnt = db.query(QuizAttempt).filter(QuizAttempt.submitted == True, QuizAttempt.start_time >= seven_days_ago).count()
        monthly_cnt = db.query(QuizAttempt).filter(QuizAttempt.submitted == True, QuizAttempt.start_time >= thirty_days_ago).count()

        # Category-wise performance
        categories = db.query(Question.category).distinct().all()
        category_perf = []
        for (cat_name,) in categories:
            quizzes_count = db.query(Quiz).filter(Quiz.category.ilike(f"%{cat_name}%")).count()
            q_count = db.query(Question).filter(Question.category == cat_name).count()

            # Attempts for quizzes in this category
            att_query = (
                db.query(func.count(QuizAttempt.id), func.avg(QuizAttempt.percentage))
                .join(Quiz, QuizAttempt.quiz_id == Quiz.id)
                .filter(QuizAttempt.submitted == True, Quiz.category.ilike(f"%{cat_name}%"))
                .first()
            )
            cat_att_cnt = att_query[0] if att_query else 0
            cat_avg = round(float(att_query[1]), 2) if att_query and att_query[1] is not None else 0.0

            category_perf.append(CategoryPerformance(
                category=cat_name,
                total_quizzes=quizzes_count,
                total_questions=q_count,
                attempts_count=cat_att_cnt,
                average_score=cat_avg
            ))

        # User growth trend (grouped by date formatted YYYY-MM-DD for last 7 days)
        growth_trend = {}
        for i in range(6, -1, -1):
            dt = (now - timedelta(days=i)).strftime("%Y-%m-%d")
            start_dt = datetime.strptime(dt, "%Y-%m-%d").replace(tzinfo=timezone.utc)
            end_dt = start_dt + timedelta(days=1)
            u_count = db.query(User).filter(User.created_at >= start_dt, User.created_at < end_dt).count()
            growth_trend[dt] = u_count

        # Most attempted quiz
        most_att_quiz_res = (
            db.query(Quiz.title, func.count(QuizAttempt.id).label("cnt"))
            .join(QuizAttempt, QuizAttempt.quiz_id == Quiz.id)
            .filter(QuizAttempt.submitted == True)
            .group_by(Quiz.id)
            .order_by(desc("cnt"))
            .first()
        )
        most_attempted = {"title": most_att_quiz_res[0], "attempts": str(most_att_quiz_res[1])} if most_att_quiz_res else {"title": "N/A", "attempts": "0"}

        # Popular categories by quiz count
        pop_cats_res = db.query(Quiz.category, func.count(Quiz.id)).group_by(Quiz.category).order_by(desc(func.count(Quiz.id))).limit(5).all()
        most_popular_categories = [{"category": cat, "quiz_count": count} for cat, count in pop_cats_res]

        # Most difficult questions (highest wrong answer percentage)
        most_diff_res = (
            db.query(
                Question.id,
                Question.question_text,
                Question.category,
                Question.difficulty,
                func.count(UserAnswer.id).label("total_ans"),
                func.sum(case((UserAnswer.is_correct == False, 1), else_=0)).label("wrong_ans")
            )
            .join(UserAnswer, UserAnswer.question_id == Question.id)
            .group_by(Question.id)
            .having(func.count(UserAnswer.id) >= 2)
            .order_by(desc(func.sum(case((UserAnswer.is_correct == False, 1), else_=0)) / func.count(UserAnswer.id)))
            .limit(5)
            .all()
        )

        most_difficult_questions = []
        for q_id, q_text, q_cat, q_diff, total_ans, wrong_ans in most_diff_res:
            wrong_pct = round((float(wrong_ans) / float(total_ans)) * 100.0, 2)
            most_difficult_questions.append(MostDifficultQuestion(
                question_id=q_id,
                question_text=q_text,
                category=q_cat,
                difficulty=str(q_diff),
                total_attempts=total_ans,
                wrong_percentage=wrong_pct
            ))

        return AdminDashboardAnalytics(
            total_users=total_users,
            total_questions=total_questions,
            total_choices=total_choices,
            total_quizzes=total_quizzes,
            total_attempts=total_attempts,
            average_score=average_score,
            pass_percentage=pass_percentage,
            difficulty_breakdown=diff_breakdown,
            category_wise_performance=category_perf,
            daily_attempts_count=daily_cnt,
            weekly_attempts_count=weekly_cnt,
            monthly_attempts_count=monthly_cnt,
            user_growth_trend=growth_trend,
            most_attempted_quiz=most_attempted,
            most_popular_categories=most_popular_categories,
            most_difficult_questions=most_difficult_questions
        )

    @staticmethod
    def get_user_score_summary(db: Session, user_id: int) -> UserScoreSummary:
        attempts = db.query(QuizAttempt).filter(QuizAttempt.user_id == user_id, QuizAttempt.submitted == True).all()
        total_attempts = len(attempts)

        if total_attempts == 0:
            return UserScoreSummary(
                user_id=user_id,
                total_attempts=0,
                highest_score=0.0,
                average_score=0.0,
                correct_answers_count=0,
                wrong_answers_count=0,
                overall_accuracy_percentage=0.0,
                category_scores={},
                quiz_scores={}
            )

        highest_score = max(a.score for a in attempts)
        avg_score = round(sum(a.score for a in attempts) / float(total_attempts), 2)

        # Correct & wrong answers breakdown
        ans_query = (
            db.query(UserAnswer.is_correct, func.count(UserAnswer.id))
            .join(QuizAttempt, UserAnswer.attempt_id == QuizAttempt.id)
            .filter(QuizAttempt.user_id == user_id, QuizAttempt.submitted == True)
            .group_by(UserAnswer.is_correct)
            .all()
        )
        correct_cnt = 0
        wrong_cnt = 0
        for is_corr, count in ans_query:
            if is_corr:
                correct_cnt = count
            else:
                wrong_cnt = count

        total_ans = correct_cnt + wrong_cnt
        overall_accuracy = round((correct_cnt / float(total_ans)) * 100.0, 2) if total_ans > 0 else 0.0

        # Category scores
        cat_query = (
            db.query(Quiz.category, func.avg(QuizAttempt.percentage))
            .join(Quiz, QuizAttempt.quiz_id == Quiz.id)
            .filter(QuizAttempt.user_id == user_id, QuizAttempt.submitted == True)
            .group_by(Quiz.category)
            .all()
        )
        category_scores = {cat: round(float(pct), 2) for cat, pct in cat_query}

        # Quiz-wise scores
        quiz_query = (
            db.query(Quiz.title, func.max(QuizAttempt.score))
            .join(Quiz, QuizAttempt.quiz_id == Quiz.id)
            .filter(QuizAttempt.user_id == user_id, QuizAttempt.submitted == True)
            .group_by(Quiz.title)
            .all()
        )
        quiz_scores = {title: float(score) for title, score in quiz_query}

        return UserScoreSummary(
            user_id=user_id,
            total_attempts=total_attempts,
            highest_score=highest_score,
            average_score=avg_score,
            correct_answers_count=correct_cnt,
            wrong_answers_count=wrong_cnt,
            overall_accuracy_percentage=overall_accuracy,
            category_scores=category_scores,
            quiz_scores=quiz_scores
        )


analytics_service = AnalyticsService()
