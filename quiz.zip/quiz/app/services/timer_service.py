from datetime import datetime, timedelta, timezone
from typing import Tuple
from app.models.attempt import QuizAttempt
from app.models.quiz import Quiz


class TimerService:
    @staticmethod
    def calculate_expected_end_time(start_time: datetime, duration_minutes: int) -> datetime:
        """Calculates the cutoff timestamp for a quiz attempt."""
        return start_time + timedelta(minutes=duration_minutes)

    @staticmethod
    def get_timer_status(attempt: QuizAttempt, quiz: Quiz) -> Tuple[datetime, int, bool]:
        """
        Returns (expected_end_time, remaining_seconds, is_expired).
        Guarantees backend enforces exact strict duration bounds.
        """
        start = attempt.start_time
        if start.tzinfo is None:
            start = start.replace(tzinfo=timezone.utc)

        expected_end = start + timedelta(minutes=quiz.duration)
        now = datetime.now(timezone.utc)

        diff_seconds = int((expected_end - now).total_seconds())
        is_expired = diff_seconds <= 0

        remaining_seconds = max(0, diff_seconds)
        return expected_end, remaining_seconds, is_expired


timer_service = TimerService()
