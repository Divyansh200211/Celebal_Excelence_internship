import random
from typing import List, Tuple, Dict, Any, Optional
from sqlalchemy.orm import Session
from app.models.question import Question, Choice, DifficultyLevel
from app.models.quiz import Quiz, QuizQuestion
from app.models.attempt import QuizAttempt, UserAnswer
from app.schemas.quiz import QuizCreate, RandomQuizGenerateRequest, CategoryQuizGenerateRequest, DifficultyQuizGenerateRequest, MixedQuizGenerateRequest
from app.crud.crud_quiz import crud_quiz
from app.crud.crud_attempt import crud_attempt
from app.crud.crud_leaderboard import crud_leaderboard
from app.core.exceptions import BadRequestException, NotFoundException


class QuizService:
    @staticmethod
    def evaluate_attempt_submission(
        db: Session,
        attempt: QuizAttempt,
        quiz: Quiz,
        submitted_answers: List[Dict[str, Any]]
    ) -> Tuple[float, float, List[UserAnswer]]:
        """
        Evaluates submitted answer choices against correct database choices.
        Calculates total score and percentage.
        """
        quiz_questions = crud_quiz.get_quiz_questions(db, quiz.id)
        if not quiz_questions:
            return 0.0, 0.0, []

        marks_per_question = quiz.total_marks / float(len(quiz_questions))
        answer_map = {ans["question_id"]: ans.get("selected_choice_id") for ans in submitted_answers}

        total_score = 0.0
        saved_user_answers = []

        for q in quiz_questions:
            selected_choice_id = answer_map.get(q.id)
            is_correct = False

            if selected_choice_id:
                # verify if choice belongs to question and is_correct
                choice = db.query(Choice).filter(Choice.id == selected_choice_id, Choice.question_id == q.id).first()
                if choice and choice.is_correct:
                    is_correct = True
                    total_score += marks_per_question

            ua = crud_attempt.save_user_answer(
                db=db,
                attempt_id=attempt.id,
                question_id=q.id,
                selected_choice_id=selected_choice_id,
                is_correct=is_correct
            )
            saved_user_answers.append(ua)

        percentage = round((total_score / float(quiz.total_marks)) * 100.0, 2)
        final_score = round(total_score, 2)

        # Finalize attempt in DB
        crud_attempt.finalize_attempt(db, attempt, final_score, percentage)

        # Update Leaderboard
        crud_leaderboard.update_or_create_entry(db, quiz.id, attempt.user_id, final_score)

        return final_score, percentage, saved_user_answers

    @staticmethod
    def generate_random_quiz(db: Session, req: RandomQuizGenerateRequest) -> Quiz:
        all_questions = db.query(Question).filter(Question.category.ilike(f"%{req.category}%")).all() if req.category else db.query(Question).all()
        if len(all_questions) < req.num_questions:
            raise BadRequestException(f"Not enough questions available in category. Requested: {req.num_questions}, Available: {len(all_questions)}")

        selected_q = random.sample(all_questions, req.num_questions)
        q_create = QuizCreate(
            title=req.title,
            description=req.description,
            category=req.category,
            duration=req.duration,
            total_marks=len(selected_q) * 10,
            question_ids=[q.id for q in selected_q]
        )
        return crud_quiz.create(db, q_create)

    @staticmethod
    def generate_category_quiz(db: Session, req: CategoryQuizGenerateRequest) -> Quiz:
        return QuizService.generate_random_quiz(
            db,
            RandomQuizGenerateRequest(
                title=req.title,
                description=req.description,
                category=req.category,
                num_questions=req.num_questions,
                duration=req.duration
            )
        )

    @staticmethod
    def generate_difficulty_quiz(db: Session, req: DifficultyQuizGenerateRequest) -> Quiz:
        query = db.query(Question).filter(Question.difficulty == req.difficulty)
        if req.category:
            query = query.filter(Question.category.ilike(f"%{req.category}%"))
        questions = query.all()

        if len(questions) < req.num_questions:
            raise BadRequestException(f"Not enough {req.difficulty} questions available. Requested: {req.num_questions}, Available: {len(questions)}")

        selected_q = random.sample(questions, req.num_questions)
        category_name = req.category if req.category else f"{req.difficulty.capitalize()} Difficulty Quiz"

        q_create = QuizCreate(
            title=req.title,
            description=req.description,
            category=category_name,
            duration=req.duration,
            total_marks=len(selected_q) * 10,
            question_ids=[q.id for q in selected_q]
        )
        return crud_quiz.create(db, q_create)

    @staticmethod
    def generate_mixed_quiz(db: Session, req: MixedQuizGenerateRequest) -> Quiz:
        easy_q = db.query(Question).filter(Question.difficulty == DifficultyLevel.EASY)
        medium_q = db.query(Question).filter(Question.difficulty == DifficultyLevel.MEDIUM)
        hard_q = db.query(Question).filter(Question.difficulty == DifficultyLevel.HARD)

        if req.category:
            easy_q = easy_q.filter(Question.category.ilike(f"%{req.category}%"))
            medium_q = medium_q.filter(Question.category.ilike(f"%{req.category}%"))
            hard_q = hard_q.filter(Question.category.ilike(f"%{req.category}%"))

        easy_list = easy_q.all()
        medium_list = medium_q.all()
        hard_list = hard_q.all()

        if len(easy_list) < req.num_easy or len(medium_list) < req.num_medium or len(hard_list) < req.num_hard:
            raise BadRequestException(
                f"Insufficient questions for mixed quiz. Required (E:{req.num_easy}, M:{req.num_medium}, H:{req.num_hard}). "
                f"Available (E:{len(easy_list)}, M:{len(medium_list)}, H:{len(hard_list)})."
            )

        selected = random.sample(easy_list, req.num_easy) + random.sample(medium_list, req.num_medium) + random.sample(hard_list, req.num_hard)
        random.shuffle(selected)

        category_name = req.category if req.category else "Mixed Domain Quiz"
        q_create = QuizCreate(
            title=req.title,
            description=req.description,
            category=category_name,
            duration=req.duration,
            total_marks=len(selected) * 10,
            question_ids=[q.id for q in selected]
        )
        return crud_quiz.create(db, q_create)


quiz_service = QuizService()
