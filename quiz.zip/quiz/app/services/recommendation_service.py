from datetime import datetime, timezone
import numpy as np
import pandas as pd
from typing import List, Dict, Any
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from sqlalchemy.orm import Session

from app.models.user import User
from app.models.quiz import Quiz
from app.models.attempt import QuizAttempt
from app.models.recommendation import RecommendationHistory
from app.schemas.quiz import QuizResponse
from app.schemas.recommendation import SingleRecommendationItem, RecommendationListResponse
from app.crud.crud_quiz import crud_quiz


class RecommendationEngine:
    def recommend_quizzes_for_user(
        self,
        db: Session,
        user_id: int,
        top_n: int = 5
    ) -> RecommendationListResponse:
        user = db.query(User).filter(User.id == user_id).first()
        all_quizzes = db.query(Quiz).all()

        if not all_quizzes:
            return RecommendationListResponse(
                user_id=user_id,
                generated_at=datetime.now(timezone.utc),
                recommendations=[]
            )

        # Get historical submitted attempts
        user_attempts = (
            db.query(QuizAttempt)
            .filter(QuizAttempt.user_id == user_id, QuizAttempt.submitted == True)
            .all()
        )

        attempted_quiz_ids = {a.quiz_id for a in user_attempts}

        # Build TF-IDF representations of quizzes (title + description + category)
        quiz_corpus = [f"{q.title} {q.description} {q.category}" for q in all_quizzes]
        vectorizer = TfidfVectorizer(stop_words='english')
        quiz_tfidf = vectorizer.fit_transform(quiz_corpus)

        # Calculate category accuracy breakdown for user
        cat_performance: Dict[str, List[float]] = {}
        for att in user_attempts:
            q_obj = next((q for q in all_quizzes if q.id == att.quiz_id), None)
            if q_obj:
                cat_performance.setdefault(q_obj.category, []).append(att.percentage)

        weak_categories = set()
        strong_categories = set()
        for cat, pcts in cat_performance.items():
            avg_pct = np.mean(pcts)
            if avg_pct < 60.0:
                weak_categories.add(cat)
            elif avg_pct >= 80.0:
                strong_categories.add(cat)

        # If user has no attempts, recommend top diverse quizzes
        recommendations: List[SingleRecommendationItem] = []

        if not user_attempts:
            # Cold-start recommendations
            for q in all_quizzes[:top_n]:
                q_resp = QuizResponse.model_validate(q)
                q_resp.question_count = len(q.quiz_questions)
                recommendations.append(
                    SingleRecommendationItem(
                        quiz=q_resp,
                        match_score=0.85,
                        reason="Popular starter quiz to test your knowledge.",
                        predicted_score=75.0
                    )
                )
        else:
            # Content-based & Collaborative Recommendation logic using TF-IDF + Weak category boosting
            user_avg_score = np.mean([a.percentage for a in user_attempts])

            # Build user profile TF-IDF text from highly rated or attempted quizzes
            profile_text = " ".join([
                f"{q.title} {q.category}"
                for q in all_quizzes if q.id in attempted_quiz_ids
            ])
            user_vector = vectorizer.transform([profile_text])
            similarity_scores = cosine_similarity(user_vector, quiz_tfidf).flatten()

            candidates = []
            for idx, q in enumerate(all_quizzes):
                base_sim = float(similarity_scores[idx])

                # Boost score if category is weak (to help student improve)
                category_boost = 0.0
                reason_parts = []

                if q.category in weak_categories:
                    category_boost += 0.35
                    reason_parts.append(f"Focus area to boost low accuracy in {q.category}.")
                elif q.category in strong_categories:
                    category_boost += 0.15
                    reason_parts.append(f"Mastery challenge in your strong category {q.category}.")

                # Penalty for recently attempted quizzes
                if q.id in attempted_quiz_ids:
                    penalty = -0.40
                    reason_parts.append("Previously attempted quiz for retake & revision.")
                else:
                    penalty = 0.20
                    reason_parts.append("New unattempted quiz matching your interest.")

                final_match_score = round(min(1.0, max(0.1, base_sim + category_boost + penalty)), 2)
                predicted_score = round(min(100.0, max(40.0, user_avg_score + (category_boost * 10))), 1)
                reason_str = " ".join(reason_parts) if reason_parts else "Recommended based on your learning trajectory."

                candidates.append((q, final_match_score, reason_str, predicted_score))

            # Sort by match score descending
            candidates.sort(key=lambda x: x[1], reverse=True)

            for q, match_score, reason, pred_score in candidates[:top_n]:
                q_resp = QuizResponse.model_validate(q)
                q_resp.question_count = len(q.quiz_questions)

                # Persist to database history
                rec_hist = RecommendationHistory(
                    user_id=user_id,
                    quiz_id=q.id,
                    reason=reason,
                    score_prediction=pred_score,
                    generated_at=datetime.now(timezone.utc)
                )
                db.add(rec_hist)

                recommendations.append(
                    SingleRecommendationItem(
                        quiz=q_resp,
                        match_score=match_score,
                        reason=reason,
                        predicted_score=pred_score
                    )
                )

            db.commit()

        return RecommendationListResponse(
            user_id=user_id,
            generated_at=datetime.now(timezone.utc),
            recommendations=recommendations
        )


recommendation_engine = RecommendationEngine()
