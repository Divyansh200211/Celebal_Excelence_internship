# 🧠 Quiz Engine API

[![FastAPI](https://img.shields.io/badge/FastAPI-0.110.0-009688.svg?style=flat&logo=fastapi)](https://fastapi.tiangolo.com/)
[![Python](https://img.shields.io/badge/Python-3.12+-3776AB.svg?style=flat&logo=python&logoColor=white)](https://www.python.org/)
[![SQLAlchemy](https://img.shields.io/badge/SQLAlchemy-2.0-red.svg?style=flat&logo=sqlalchemy)](https://www.sqlalchemy.org/)
[![Scikit-Learn](https://img.shields.io/badge/Scikit--Learn-ML%20Engine-F7931E.svg?style=flat&logo=scikit-learn)](https://scikit-learn.org/)
[![Docker](https://img.shields.io/badge/Docker-Ready-2496ED.svg?style=flat&logo=docker&logoColor=white)](https://www.docker.com/)

A modern, production-ready RESTful API for building learning platforms and assessment apps. Built with **FastAPI**, **SQLAlchemy 2.0**, **Pydantic v2**, and an integrated **Scikit-Learn recommendation engine** that targets student weak spots.

Whether you need server-enforced countdown timers, dynamic quiz generation, role-based access, or live leaderboards—this backend has everything wired up and ready to run.

---

## 💡 Why Build This?

Most quiz backends are either too basic (just CRUD questions) or overly complex without solving core student learning needs. 

This project delivers a **complete, real-world backend blueprint**:
- **Cheat-proof timing**: Quiz countdowns are tracked and verified on the server side so users can't modify client clocks.
- **Adaptive learning**: Instead of static suggestions, an embedded ML engine analyzes past attempts, spots weak categories (accuracy < 60%), and recommends targeted practice quizzes.
- **Role-tailored experiences**: Admins get deep analytical insights and quiz creation tools, while students get timed attempts, reports, and global leaderboards.

Need a step-by-step walkthrough for total beginners? Check out the **[Beginner's Run Guide (RUN.md)](file:///d:/QuizAG/RUN.md)**.

---

## ✨ Feature Overview

- **🔐 Auth & RBAC**: OAuth2 JWT authentication with access/refresh token rotation and password hashing (`bcrypt`). Role protection for `Admin` and `Student`.
- **📝 Question & Quiz Management**: Full CRUD operations for questions and choice options with cascading cleanups.
- **🎲 Dynamic Quiz Generators**: Generate quizzes on the fly based on domain, difficulty level (Easy/Medium/Hard), or custom question counts.
- **⏱️ Server-Enforced Quiz Timers**: Track ongoing attempt time remaining, prevent late answers, and auto-finalize expired attempts.
- **🧠 ML Recommendation Engine**: Driven by Scikit-Learn (TF-IDF vectorization + Cosine Similarity) with dynamic weak-category score boosting (+0.35).
- **🏆 Live Leaderboards**: Global, per-quiz, weekly (7-day), and monthly (30-day) student rank tables.
- **📊 Analytics Dashboards**: Visualizable metrics covering completion rates, hardest questions, category-level accuracy, and user growth.
- **🌱 One-Command Seeding**: Ships with a seeding script that instantly populates 100 questions across 6 domains, 20 quizzes, and 50 accounts.
- **🐳 Dockerized Deployment**: Run everything locally or in production with zero setup headaches via Docker Compose.

---

## 🧰 Tech Stack

| Layer | Technology | Why It Was Chosen |
|---|---|---|
| **Framework** | [FastAPI](https://fastapi.tiangolo.com/) | Blazing fast asynchronous execution and auto-generated OpenAPI documentation. |
| **Database & ORM** | [SQLAlchemy 2.0](https://www.sqlalchemy.org/) & SQLite | Modern type-safe queries. Easily configured for PostgreSQL or MySQL. |
| **Validation** | [Pydantic v2](https://docs.pydantic.dev/) | High-performance schema validation and request serialization. |
| **Security** | JWT (`python-jose`) & `passlib` | Industry-standard bearer token security with salted bcrypt hashing. |
| **Machine Learning** | [Scikit-Learn](https://scikit-learn.org/), Pandas, NumPy | Content-based filtering and TF-IDF feature mapping for smart quiz suggestions. |
| **Testing** | [Pytest](https://docs.pytest.org/) & HTTPX | Comprehensive suite running in-memory for instant feedback. |

---

## 📁 Project Architecture

```text
d:\QuizAG\
├── app/
│   ├── main.py                   # FastAPI app setup, CORS, router mounts & exception handlers
│   ├── config.py                 # Pydantic BaseSettings environment loader
│   ├── database.py               # Database engine & session session makers
│   ├── dependencies.py           # Authentication & RBAC guard dependencies
│   ├── core/
│   │   ├── security.py           # JWT creation/verification & bcrypt helpers
│   │   └── exceptions.py         # Custom HTTP exceptions and global error handlers
│   ├── models/                   # SQLAlchemy 2.0 models
│   │   ├── user.py               # User identity & roles (Admin vs Student)
│   │   ├── question.py           # Question & Choice models (with cascade delete)
│   │   ├── quiz.py               # Quiz & QuizQuestion association model
│   │   ├── attempt.py            # QuizAttempt & UserAnswer models
│   │   ├── leaderboard.py        # Leaderboard performance records
│   │   └── recommendation.py     # AI recommendation history logs
│   ├── schemas/                  # Pydantic validation schemas
│   │   ├── common.py             # Pagination & standard envelope schemas
│   │   ├── user.py               # Auth & user schemas
│   │   ├── question.py           # Question CRUD schemas
│   │   ├── quiz.py               # Quiz generator & creation schemas
│   │   ├── attempt.py            # Active timer & attempt payload schemas
│   │   ├── leaderboard.py        # Leaderboard rank schemas
│   │   ├── analytics.py          # Dashboard metric response schemas
│   │   └── recommendation.py     # ML suggestion schemas
│   ├── crud/                     # Repository layer (Database operations)
│   │   ├── crud_user.py          # User queries
│   │   ├── crud_question.py      # Question management
│   │   ├── crud_quiz.py          # Quiz creation & assignment
│   │   ├── crud_attempt.py       # Attempt submission & answer logging
│   │   └── crud_leaderboard.py    # Rank calculations
│   ├── services/                 # Business logic
│   │   ├── timer_service.py      # Server clock tracking & remaining time engine
│   │   ├── quiz_service.py       # Dynamic quiz generation & scoring
│   │   ├── analytics_service.py  # Admin/student dashboard metrics aggregation
│   │   └── recommendation_service.py # Scikit-Learn TF-IDF weak category booster engine
│   └── routers/                  # API Controllers
│       ├── auth.py               # /login, /refresh, /me
│       ├── users.py              # User management
│       ├── questions.py          # Question CRUD
│       ├── choices.py            # Choice options CRUD
│       ├── quizzes.py            # Quiz operations & generator
│       ├── attempts.py           # Start timer, submit attempt, view report
│       ├── leaderboard.py        # Rankings
│       ├── analytics.py          # Metrics dashboards
│       └── recommendations.py    # AI recommendations
├── alembic/                      # Database migration scripts
├── tests/                        # Automated Pytest suite
├── seed_data.py                  # Seed script populating sample datasets
├── requirements.txt              # Dependency manifest
├── Dockerfile                    # Single container specification
├── docker-compose.yml            # Multi-container service orchestrator
└── README.md                     # Project documentation
```

---

## ⚡ Quick Start Guide

### 1. Prerequisites
Make sure you have **Python 3.12+** and **Git** installed on your machine.

### 2. Setup Environment
Clone or open the repository, then create and activate a virtual environment:

```bash
# Navigate to project folder
cd d:\QuizAG

# Windows (PowerShell)
python -m venv venv
.\venv\Scripts\Activate.ps1

# Linux / macOS
python3 -m venv venv
source venv/bin/activate
```

### 3. Install Dependencies
```bash
pip install -r requirements.txt
```

### 4. Seed the Database
Populate your local SQLite database with initial sample data (100 questions, 20 quizzes, 50 users):

```bash
python seed_data.py
```

### 5. Launch the Server
Start the Uvicorn development server:

```bash
uvicorn app.main:app --reload
```

Your API is now running live at **`http://127.0.0.1:8000`**! 🎉

---

## 🔐 Credentials & Interactive API Docs

Once the server is running, head over to your browser to test endpoints visually:

- 📖 **Interactive Swagger UI**: [http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs)
- 📑 **ReDoc Documentation**: [http://127.0.0.1:8000/redoc](http://127.0.0.1:8000/redoc)

### Ready-to-Use Accounts

Click the **Authorize 🔓** button in Swagger UI and log in with either:

| Role | Username | Password | Access Capabilities |
|---|---|---|---|
| **Admin** | `admin` | `AdminPassword123!` | Create/Edit/Delete questions & quizzes, run generators, view admin metrics. |
| **Student** | `alexsmith1` | `StudentPassword123!` | Start timed quizzes, submit answers, check leaderboards, view recommendations. |

---

## 🤖 How the Recommendation Engine Works

The smart recommendation service helps students plug knowledge gaps rather than just retaking familiar topics:

```mermaid
graph TD
    A[Student Quiz Attempts] --> B[Calculate Category Accuracy %]
    B --> C{Accuracy < 60%?}
    C -- Yes --> D[Flag as Weak Category: Apply +0.35 Score Boost]
    C -- No --> E[Standard TF-IDF Similarity Weight]
    D --> F[Scikit-Learn Cosine Similarity Matrix]
    E --> F
    F --> G[Rank & Return Top Unattempted Quizzes]
```

1. **Text Vectorization**: Extracts text features from quiz titles, category metadata, and tags using TF-IDF.
2. **Cosine Similarity**: Measures overlap between a student's successful past quiz topics and available unattempted quizzes.
3. **Weak Category Boosting**: Automatically identifies categories where student accuracy falls below **60%** and applies a **+0.35 boost factor** to target weak spots.

---

## 🧪 Running Tests

Run the full automated `pytest` suite:

```bash
python -m pytest tests/ -v
```

All unit and integration tests run against an isolated in-memory SQLite instance, keeping your local database clean.

---

## 🐳 Docker Setup

Prefer running with Docker? Spin up the full application with a single command:

```bash
docker-compose up --build
```

The container automatically seeds sample data and exposes the API on `http://localhost:8000`.

---

## 🔮 What's Next?

Got ideas or want to extend the platform? Here's what's planned:
- [ ] **Redis Cache**: Offload active timer state and global leaderboards to Redis for sub-millisecond lookups.
- [ ] **Rich Media Questions**: Support embedded code blocks, images, and diagram-based questions.
- [ ] **Live Multiplayer Quizzes**: Real-time WebSockets for hosted classroom quiz games.
- [ ] **Export Reports**: Generate downloadable PDF and CSV performance analytics reports.

---

<p center>Crafted with care for developers, educators, and learners. 🚀</p>

